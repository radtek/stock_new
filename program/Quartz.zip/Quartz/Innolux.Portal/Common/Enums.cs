using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Innolux.Portal.Common
{
    #region For schedulable report
    public enum PastDateTimeType
    {
        Hour = 0,
        Day,
        Week,
        Month
    }

    public enum OutputAvailability
    { 
        Private = 0,
        Public
    }
    #endregion

    public enum DateTimeType { Daily = 0, Hourly, Weekly, Monthly, Unknow }

    public enum HolidayType
    {
        Working = 0,
        Holiday
    }

    public enum MailAddressType
    {
        From = 0,
        TO = 1,
        CC
    }
    public enum MailFormatType
    {
        Html = 0,
        XML = 1,
        Text
    }

    /// <summary>
    /// Report send frequency
    /// </summary>
    public enum ReportFrequency
    {
        /// <summary>
        /// Run frequency is every day
        /// </summary>
        Daily = 1,
        /// <summary>
        /// Weekly report, need konw 
        /// </summary>
        Weekly = 2,
        Monthly = 3,
        Mintue = 4,
        Hourly = 5,
        All
    }

    /// <summary>
    /// when report send admin , the report process status 
    /// </summary>
    public enum JobRunStatus
    {
        DataCheckFailed = 1,
        CreateFileFailed = 2,
        ZipFileFailed = 3,
        FtpUploadFailed = 4,
        SendMailFailed = 5,
        WaitTimeOut = 6,
        RunJobSuccess = 9,
        UnknowError = 10
    }

    /// <summary>
    /// to every report, define operate order
    /// </summary>
    public enum ReportOperateOrder
    {
        DataCheck = 1,
        ExportFile = 2,
        ZilFile = 3,
        FtpUpload = 4,
        SendExporFile = 5
    }
}
