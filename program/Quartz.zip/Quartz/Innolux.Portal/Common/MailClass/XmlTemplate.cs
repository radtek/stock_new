using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using Innolux.Portal.Common;
using Innolux.Portal.Common.FileClass;

namespace Innolux.Portal.Common.MailClass
{
    /// <summary>
    /// Summary description for XmlMailProvider
    /// </summary>
    public class XmlTemplate : ITemplate
    {
        private string fileName = string.Empty;

        #region Public property
        private string trxID = "AUTOREPORT";
        /// <summary>
        /// Only Set
        /// </summary>
        public string TrxID
        {
            get { return this.trxID; }
        }

        private string typeID = "I";
        /// <summary>
        /// Only Set
        /// </summary>
        public string TypeID
        {
            get { return this.typeID; }
        }

        private string fabID = "T2";
        /// <summary>
        /// Get or Set
        /// </summary>
        public string FabID
        {
            get { return this.fabID; }
            set { this.fabID = value; }
        }

        private string sysType = "BC";
        public string SysType
        {
            get { return this.sysType; }
            set { this.sysType = value; }
        }

        private string eqID = "T2-000000";
        public string EqID
        {
            get { return this.eqID; }
            set { this.eqID = value; }
        }

        private string alarmID = "REPORT";
        /// <summary>
        /// only Get the alarmID, default "REPORT" 
        /// </summary>
        public string AlarmID
        {
            get { return this.alarmID; }
            set { this.alarmID = value; }
        }

        private string alarmText = "Alarm happen";
        /// <summary>
        /// Get or Set the alarm-text
        /// </summary>
        public string AlarmText
        {
            get { return this.alarmText; }
            set { this.alarmText = value; }
        }

        private string maiContenType = "T";
        public string MailContenType
        {
            get { return this.maiContenType; }
            set { this.maiContenType = value; }
        }

        private string alarmCommentValue = "SERIAL_NO = xxxx,LOT_ID = xxxx,NODE_ID = xxxx Url: http://www.unicom.com.tw";
        public string AlarmCommentValue
        {
            get { return this.alarmCommentValue; }
            set { this.alarmCommentValue = value; }
        }

        private string pcIP = "127.0.0.1";
        /// <summary>
        /// Get or Set PC IP address, default "127.0.0.1"
        /// </summary>
        public string PcIP
        {
            get { return this.pcIP; }
            set { this.pcIP = value; }
        }

        private string pcName = "Unknow";
        /// <summary>
        /// Get or Set the PC Name 
        /// </summary>
        public string PcName
        {
            get { return this.pcName; }
            set { this.pcName = value; }
        }

        private string operatorName = "Unicom";
        /// <summary>
        /// Get or Set operator name 
        /// </summary>
        public string OperatorName
        {
            get { return this.operatorName; }
            set { this.operatorName = value; }
        }

        private string issueDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
        /// <summary>
        /// Get or Set issue date, format style: yyyy/MM/dd HH:mm:ss, default the current date time
        /// </summary>
        public string IssueDate
        {
            get { return this.issueDate; }
            set { this.issueDate = value; }
        }
        #endregion

        public XmlTemplate() : this(string.Empty)
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public XmlTemplate(string templateName)
        {
            if (string.IsNullOrEmpty(templateName))
                templateName = "XmlTemplate.xml";

            this.fileName = string.Format(@"{0}\Template\{1}", System.AppDomain.CurrentDomain.BaseDirectory, templateName);
        }

        private string GetXmlMail(bool encodingflag)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                if (encodingflag)
                {
                    XmlDeclaration xmldecl;
                    xmldecl = doc.CreateXmlDeclaration("1.0", "ANSI", "yes");

                    //Add   the   new   node   to   the   document.   
                    XmlElement root = doc.DocumentElement;
                    doc.InsertBefore(xmldecl, root);
                }

                doc.Load(this.fileName);

                doc.SelectSingleNode("/transaction/fab_id").InnerText = this.fabID;
                doc.SelectSingleNode("/transaction/sys_type").InnerText = this.sysType;
                doc.SelectSingleNode("/transaction/eq_id").InnerText = this.eqID;
                doc.SelectSingleNode("/transaction/alarm_id").InnerText = this.alarmID;
                doc.SelectSingleNode("/transaction/alarm_text").InnerText = this.alarmText;
                doc.SelectSingleNode("/transaction/mail_contenttype").InnerText = this.maiContenType;
                
                XmlNode node = doc.SelectSingleNode("/transaction/alarm_comment");
                node.Attributes["value"].Value = this.alarmCommentValue;

                doc.SelectSingleNode("/transaction/pc_ip").InnerText = this.pcIP;
                doc.SelectSingleNode("/transaction/pc_name").InnerText = this.pcName;
                doc.SelectSingleNode("/transaction/operator").InnerText = this.operatorName;
                doc.SelectSingleNode("/transaction/issue_date").InnerText = this.issueDate;

                return doc.InnerXml;
            }
            catch (Exception ex)
            {
                throw new Exception("Operate XML mail template error : " + ex.Message);
            }
            //return string.Empty;
        }

      
        public void ToSaveXml(string fileName, string content)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(content);
            doc.Save(fileName);
        }

        #region ITemplate Members

        public string GetTemplate(string templateName, ReportFrequency reportFrequency, bool encodingflag)
        {
            return this.GetXmlMail(encodingflag);
        }
        public string GetTemplate(string templateName, ReportFrequency reportFrequency)
        {
            return this.GetXmlMail(false);
        }
        public string GetMailSubject()
        {
            return "";
        }

        #endregion


    }
}