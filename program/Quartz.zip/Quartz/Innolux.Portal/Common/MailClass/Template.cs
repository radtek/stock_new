using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Innolux.Portal.Common.FileClass;

namespace Innolux.Portal.Common.MailClass
{
    /// <summary>
    /// Template convert class
    /// </summary>
    public class Template
    {
        #region Local variable
        private string templatePath = string.Empty;

        #endregion

        #region Public Property
        private ReportFrequency emailSendFrequency = ReportFrequency.Daily;
        /// <summary>
        /// the report execute frequency
        /// </summary>
        public ReportFrequency EmailSendFrenquency
        {
            set { this.emailSendFrequency = value; }
        }

        private DataTable dataSource;
        /// <summary>
        /// the template data source
        /// finally the data source convert to table, then insert the html
        /// </summary>
        public DataTable DataSource
        {
            set { this.dataSource = value; }
        }

        private string templateName = "Template.htm";
        /// <summary>
        /// template name, only to be set
        /// </summary>
        public string TemplateName
        {
            set 
            { 
                if(string.IsNullOrEmpty(value) == false)
                    this.templateName = value;
            }
        }

        private string userName = "Sirs";
        /// <summary>
        /// the mail arriver name, display in the above the mail
        /// </summary>
        public string UserName
        {
            set { this.userName = value; }
        }

        private string title = "�q�l���۰��I��";
        /// <summary>
        /// the mail title 
        /// </summary>
        public string Title
        {
            set { this.title = value; }
        }

        #endregion


        public Template()
        {
            //
            // TODO: Add constructor logic here
            //
            this.templatePath = string.Format(@"{0}\Fabinfo\Template", System.AppDomain.CurrentDomain.BaseDirectory);
        }

        /// <summary>
        /// Get the template string
        /// </summary>
        /// <param name="templateName">template name</param>
        /// <param name="reportFrequency">report frequency, daily, hourly, weekly, monthly</param>
        /// <param name="mailFormat">mail format</param>
        /// <returns></returns>
        public string GetTemplate(string templateName, ReportFrequency reportFrequency, MailFormatType mailFormat)
        {
            if(string.IsNullOrEmpty(templateName) == false)
                this.templateName = templateName;

            string temp = string.Format(@"{0}\{1}", this.templatePath, this.templateName);
            temp = FileHelper.ReadFile(temp);
            temp = temp.Replace("##UserName##", this.userName);
            temp = temp.Replace("##Title##", this.title);
            temp = temp.Replace("##CheckFrequency##", this.FrequencyToString(reportFrequency));
            temp = temp.Replace("##DataSource##", this.DataTableToHtmalTable(this.dataSource));
            return temp;
        }

        /// <summary>
        /// get template string
        /// </summary>
        /// <param name="reportFrequency"></param>
        /// <param name="mailFormat"></param>
        /// <returns></returns>
        public string GetTemplate(ReportFrequency reportFrequency, MailFormatType mailFormat)
        {
            this.emailSendFrequency = reportFrequency;
            string body = "";

            switch (mailFormat)
            {
                case MailFormatType.Html:
                    body = this.GetHtmlTemplate();
                    break;
                case MailFormatType.XML:
                    body = this.GetXmlTemplate();
                    break;
                default:
                    body = this.GetHtmlTemplate();
                    break;
            }

            return body;
        }

        #region Private function
        private string GetHtmlTemplate()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("<p><strong>Dear  Sirs, <br />");
            sb.Append("<br />");
            sb.Append("TITLE: </strong><strong>�q�l���۰��I��</strong><strong> <br />");
            sb.Append("<br />");
            sb.Append("SYSTEM: </strong><strong>�ŦX�q�l���[�c��</strong><strong>CIM</strong><strong>�U�t�Ρ@</strong><strong> </strong><br />");
            sb.Append("<br />");
            sb.Append("<hr color=#333366 size=4 />");

            // 
            switch (this.emailSendFrequency)
            {
                case ReportFrequency.Mintue:
                    sb.Append("<H1>Minute_CHK</H1>");
                    break;
                case ReportFrequency.Hourly:
                    sb.Append("<H1>Hourly_CHK</H1>");
                    break;
                case ReportFrequency.Daily:
                    sb.Append("<H1>Daily_CHK</H1>");
                    break;
                case ReportFrequency.Weekly:
                    sb.Append("<H1>Weekly_CHK</H1>");
                    break;
                case ReportFrequency.Monthly:
                    sb.Append("<H1>Monthly_CHK</H1>");
                    break;
                default:
                    sb.Append("<H1>Report_CHK</H1>");
                    break;
            }
            sb.Append("<table style='font-family:Arial;' bordercolor =Black cellpadding='1' cellspacing='1'>");
            sb.Append("<tr bgcolor=#003366 style='color:White'>");
            sb.Append("<td>&nbsp;REPORTID&nbsp;</td>");
            sb.Append("<td>&nbsp;REPORTNAME&nbsp;</td>");
            sb.Append("<td>&nbsp;STATUS&nbsp;</td>");
            sb.Append("<td>&nbsp;RUNDATETIME&nbsp;</td>");
            sb.Append("<td>&nbsp;MESSAGE&nbsp;</td>");
            sb.Append("</tr>");

            if (dataSource != null && dataSource.Rows.Count > 0)
            {
                for (int i = 0; i < dataSource.Rows.Count; i++)
                {
                    sb.Append("<tr bgcolor=#fcfefe>");
                    sb.Append("<td>&nbsp;" + (i + 1) + "&nbsp;</td>");
                    sb.Append("<td>&nbsp;ReportHealthCheck &nbsp;</td>");
                    sb.Append("<td>&nbsp;Run_finished &nbsp;</td>");
                    sb.Append("<td>&nbsp;" + DateTime.Now.AddMinutes(-20).ToString("yyyy-MM-dd HH:mm:ss") + "&nbsp;</td>");
                    sb.Append("<td>&nbsp;Run Job Successfully &nbsp;</td>");
                    sb.Append("</tr>");
                }
            }

            sb.Append("</table>");
            sb.Append("<hr color=#333366 size=4 />");
            sb.Append("<br />");
            sb.Append("�q�l���۰��I�˨t�ΡG<br />");
            sb.Append("<br />");
            sb.Append("�\��G�۰��I��CIM�q�l���ɮת����ͥH�αH�e���p <br />");
            sb.Append("<br />");
            sb.Append("�I�ˮɶ��G�C�� 8:00 �H�� 16:35 <br />");
            sb.Append("<br />");
            sb.Append("�ɮײ��ͪ��ܪk�G���`(Y)/���`(N) <br />");
            sb.Append("<br />");
            sb.Append("�ɮױH�e���ܪk�G���`(Y)/���`(N) <br />");
            sb.Append("<br />");
            sb.Append("�H�W�U�t���I�˭Y�����`�Ш̷ӦU�t��SOP�B�z");

            return sb.ToString();
        }

        private string GetXmlTemplate()
        {
            StringBuilder sb = new StringBuilder();
            string strXml = "<?xml version=\"1.0\"?> " + "\r\n" +
                "<transaction>" + "\r\n\t" +
                    "<trx_id>" + "111" + "</trx_id>" + "\r\n\t" +
                    "<type_id>" + "111" + "</type_id>" + "\r\n\t" +
                    "<fab_id>" + "111" + "</fab_id>" + "\r\n\t" +
                    "<sys_type>" + "111" + "</sys_type>" + "\r\n\t" +
                    "<eq_id>" + "111" + "</eq_id>" + "\r\n\t" +
                    "<alarm_id>" + "111" + "</alarm_id>" + "\r\n\t" +
                    "<alarm_text>" + "111" + "</alarm_text>" + "\r\n\t" +
                    "<mail_contenttype>" + "111" + "</mail_contenttype>" + "\r\n\t" +
                    "<alarm_comment value=\"" + "111" + "\"/>" + "\r\n\t" +
                    "<pc_id>" + "pc_id" + "</pc_id>" + "\r\n\t" +
                    "<pc_name>" + "111" + "</pc_name>" + "\r\n\t" +
                    "<operator>" + "111" + "</operator>" + "\r\n\t" +
                    "<issue_date>" + "111" + "</issue_date>" + "\r\n\t" +
                "</transaction>";
            //XmlDocument doc = new XmlDocument();
            //doc.LoadXml(strXml);
            //string fileName = DateTime.Now.ToString("yyyyMMdd") + "_" + DateTime.Now.Ticks.ToString() + ".xml";
            //doc.Save(fileName);
            //return fileName;

            return sb.ToString();
        }

        private string FrequencyToString(ReportFrequency frequency)
        {
            //string temp = "Check";
            //switch (frequency)
            //{
            //    case ReportFrequency.Hourly:
            //        temp = "Hourly_Check";

            //}
            return string.Format("{0}_Check", frequency);
        }
        private string DataTableToHtmalTable(DataTable dataSource)
        {
            string tableHeader = @"
<table style='font-family:Arial;' bordercolor =Black cellpadding='1' cellspacing='1'>
";
            string title = @"
	<tr bgcolor='#003366' style='color:White'>
		<td>&nbsp;REPORTID&nbsp;</td>
		<td>&nbsp;REPORTNAME&nbsp;</td>
		<td>&nbsp;STATUS&nbsp;</td>
		<td>&nbsp;RUNDATETIME&nbsp;</td>
		<td>&nbsp;MESSAGE&nbsp;</td>
	</tr>
";
            string tableButtom = @"    
</table>
";
            string content = string.Empty;
  
            if (dataSource == null || dataSource.Columns.Count < 1)
                return string.Format("{0}{1}{2}", tableHeader, title, content, tableButtom);

            title = @"<tr bgcolor='#003366' style='color:White'>";
            for (int i = 0; i < dataSource.Columns.Count; i++)
                title += string.Format("<td>&nbsp;{0}&nbsp;</td>", dataSource.Columns[i].ColumnName);
            title += "</tr>";

            for(int i=0; i< dataSource.Rows.Count; i++)
            {
                content += "<tr>";
                for (int j = 0; j < dataSource.Columns.Count; j++)
                    content += string.Format("<td>{0}</td>", dataSource.Rows[i][j]);
                content += "</tr>";
            }

            return string.Format("{0}{1}{2}", tableHeader, title, content, tableButtom);
        }

        #endregion
    }

}
