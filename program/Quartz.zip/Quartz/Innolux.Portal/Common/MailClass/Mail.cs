using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Net.Mail;

namespace Innolux.Portal.Common.MailClass
{
    /// <summary>
    /// Mail send class
    /// </summary>
    public class Mail
    {
        #region public property
        private IList<string> from = new List<string>();
        /// <summary>
        /// Email from address list
        /// </summary>
        public IList<string> From
        {
            set { this.from = value; }
            get { return this.from; }
        }
        private IList<string> to = new List<string>();
        /// <summary>
        /// Email to address list
        /// </summary>
        public IList<string> TO
        {
            set { this.to = value; }
            get { return this.to; }
        }
        private IList<string> cc = new List<string>();
        /// <summary>
        /// Email CC address list
        /// </summary>
        public IList<string> CC
        {
            set { this.cc = value; }
            get { return this.cc; }
        }
        private IList<string> attachFiles = new List<string>();
        /// <summary>
        /// Email attach file name list
        /// </summary>
        public IList<string> AttachFiles
        {
            set { this.attachFiles = value; }
            get { return this.attachFiles; }
        }

        private string subject = "T2 CIM Job";
        /// <summary>
        /// Email subject
        /// </summary>
        public string Subject
        {
            set { this.subject = value; }
            get { return this.subject; }
        }

        private IList<string> smtpServer = new List<string>();
        /// <summary>
        /// SMTP server IP
        /// </summary>
        public IList<string> SmtpServer
        {
            set { this.smtpServer = value; }
            get { return this.smtpServer; }
        }


        private string mailServerIP = string.Empty;
        /// <summary>
        /// get or set the mail server IP
        /// </summary>
        public string MailServerIP
        {
            get { return this.mailServerIP; }
            set { this.mailServerIP = value; }
        }
        private string backupMailServerIP = string.Empty;
        /// <summary>
        /// get or set backup mail server IP
        /// </summary>
        public string BackupMailServerIP
        {
            get { return this.backupMailServerIP; }
            set { this.backupMailServerIP = value; }
        }

        private MailFormatType sendMailFormat = MailFormatType.Html;
        /// <summary>
        /// Mail format type, xml, html or text
        /// </summary>
        public MailFormatType SendMailFormat
        {
            set { this.sendMailFormat = value; }
            get { return this.sendMailFormat; }
        }

        private string errorMessage = string.Empty;
        /// <summary>
        /// Send mail exeception message
        /// </summary>
        public string ErrorMessage
        {
            get { return this.errorMessage; }
        }
        #endregion

        public Mail()
        {
            Settings.AssemblySettings asm = new Settings.AssemblySettings();
            this.mailServerIP = asm["MailServer"];
            this.backupMailServerIP = asm["BackUpMailServer"];
        }

        /// <summary>
        /// Send the mail
        /// </summary>
        /// <param name="subject">mail subject</param>
        /// <param name="body">mail body</param>
        /// <param name="attachFileName">mail attach file name </param>
        /// <param name="from">mail from address</param>
        /// <param name="to">mail to address to</param>
        /// <param name="mailServerIP">mail server IP</param>
        /// <param name="backupServerIP">mail backup server IP</param>
        /// <returns></returns>
		public bool SendMail(string subject, string body, string attachFileName, string from, string to)
		{
			return SendMail(subject, body, attachFileName, from, to, null);
		}

        /// <summary>
        /// Send mail
        /// </summary>
        /// <param name="subject">mail subject</param>
        /// <param name="body">mail body</param>
        /// <param name="attachFileName">attach file name</param>
        /// <param name="from">mail from address</param>
        /// <param name="to">mail to address</param>
        /// <param name="cc">mail to address</param>
        /// <param name="mailServerIP">mail SMTP server IP</param>
        /// <param name="backupServerIP">backup mail SMTP server IP</param>
        /// <returns></returns>
        public bool SendMail(string subject, string body, string attachFileName, string from, string to, string cc)
		{
			MailMessage mail = new MailMessage();
			mail.BodyEncoding = Encoding.UTF8;
			mail.Priority = MailPriority.Normal;
            //mail.BodyFormat = System.Web.Mail.MailFormat.Html;
            mail.IsBodyHtml = true;
            mail.From = new MailAddress(string.IsNullOrEmpty(from) ? "CIM.Alarm@innolux.com" : from);
			if (string.IsNullOrEmpty(attachFileName) == false)
			{
                Attachment attach = new Attachment(attachFileName);
				mail.Attachments.Add(attach);
			}
			mail.Subject = subject;
			mail.Body = body;
            mail.To.Add(to);
			if (!string.IsNullOrEmpty(cc))
			{
                mail.CC.Add(cc);
			}
			if (SendMail(mailServerIP, mail) == false)
			{
                return SendMail(backupMailServerIP, mail);
			}
			return true;
		}

        /// <summary>
        /// Send mail
        /// </summary>
        /// <param name="frequency">Report execute frequency, daily, hourly, weekly and monthly</param>
        /// <param name="formatType">mail context format type: XML, HTML etc. </param>
        /// <returns>bool true and false</returns>
		public bool SendMail(ReportFrequency frequency, MailFormatType formatType)
		{
			MailMessage mail = new MailMessage();
			try
			{
				if (this.SetMailInfo(mail) == false)
					return false;

				mail.Subject = this.subject;
				Template template = new Template();
				template.DataSource = new DataTable();
				mail.Body = template.GetTemplate(frequency, formatType);

				for (int i = 0; i < this.smtpServer.Count; i++)
				{
					bool success = SendMail(this.smtpServer[i], mail);
					if (success == false)
					{
						this.errorMessage += "Send mail by SMTP Server: " + this.smtpServer[i] + " defact!";
						continue;
					}
					else
					{
						return true;
					}
				}
				return false;
			}
			catch (Exception ex)
			{
				this.errorMessage = ex.Message;
				return (false);
			}
		}

        /// <summary>
        ///  If caller knows which template to use, given a template
        /// </summary>
        /// <param name="tpl"></param>
        /// <returns></returns>
        public bool SendMail(ITemplate tpl)
        {
            MailMessage mail = new MailMessage();
            try
            {
                if (this.SetMailInfo(mail) == false)
                    return false;

                mail.Subject = tpl.GetMailSubject();                
                mail.Body = tpl.GetTemplate("",ReportFrequency.All);

                for (int i = 0; i < this.smtpServer.Count; i++)
                {
                    bool success = SendMail(this.smtpServer[i], mail);
                    if (success == false)
                    {
                        this.errorMessage += "Send mail by SMTP Server: " + this.smtpServer[i] + " failed!";
                        continue;
                    }
                    else
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                this.errorMessage = ex.Message;
                return (false);
            }
        }

        public bool SendMail()
        {
			return this.SendMail(ReportFrequency.Daily, MailFormatType.Html);
        }

        /// <summary>
        /// defalult split by ; 
        /// </summary>
        /// <param name="sourceString"></param>
        /// <returns></returns>
        public IList<string> GetStringList(string sourceString)
        {
            return this.GetStringList(sourceString, ';');
        }

        /// <summary>
        /// Get the source stirng list by split char
        /// </summary>
        /// <param name="sourceString"></param>
        /// <param name="splitChar"></param>
        /// <returns></returns>
        public IList<string> GetStringList(string sourceString, char splitChar)
        {
            IList<string> list = new List<string>();

            if (string.IsNullOrEmpty(sourceString))
                return list;
            string[] arr = sourceString.Split(splitChar);
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = arr[i].Trim();
                if (string.IsNullOrEmpty(arr[i]) == false)
                    list.Add(arr[i]);
            }
            return list;
        }

        private bool SetMailInfo(MailMessage mail)
        {
            mail.BodyEncoding = Encoding.UTF8;
            mail.Priority = MailPriority.Normal;
            //mail.BodyFormat = System.Web.Mail.MailFormat.Html;
            mail.IsBodyHtml = true;

            // set default Mail From
            mail.From = new MailAddress("T2CIM.Alarm@innolux.com");
	
            //mail.To = mail.CC = null;
            if (this.to.Count < 1 && this.cc.Count < 1)
            {
                this.errorMessage = "Mail TO and CC is empty! donot to send mail.";
                return false;
            }
            for (int i = 0; i < this.to.Count; i++)
            {
                //mail.To += this.to[i] + ";";
                mail.To.Add(this.to[i]);
            }
            for (int i = 0; i < this.cc.Count; i++)
            {
                //mail.CC += this.cc + ";";
                mail.CC.Add(this.to[i]);
            }
            for (int i = 0; i < this.attachFiles.Count; i++)
            {
                Attachment attach = new Attachment(this.attachFiles[i]);
                mail.Attachments.Add(attach);
            }

            if (this.smtpServer.Count < 1)
            {
                this.errorMessage = "SMTP server is null, it must be input!";
                return false;
            }

            return true;
        }


        private bool SendMail(string smtpServer, MailMessage mail)
        {
            try
            {
                SmtpClient client = new SmtpClient(smtpServer);
                client.Send(mail);
            }
            catch (Exception ex)
            {
                this.errorMessage = ex.Message;
                return false;
            }
            return true;
        }
    }
}