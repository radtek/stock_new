using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Data;
using Innolux.Portal.Common.FileClass;

namespace Innolux.Portal.Common.MailClass
{
    /// <summary>
    ///  Html template
    /// </summary>
    public class HtmlTemplate : ITemplate
    {
        #region Local variable
        private string fileName = string.Empty;

        #endregion

        #region Public Property
        private ReportFrequency emailSendFrequency = ReportFrequency.Daily;
        /// <summary>
        /// Email send frequency, Daily Hourly, Weekly, Monthly
        /// </summary>
        public ReportFrequency EmailSendFrenquency
        {
            set { this.emailSendFrequency = value; }
        }

        private DataTable dataSource;
        /// <summary>
        /// insert html template data source 
        /// </summary>
        public DataTable DataSource
        {
            set { this.dataSource = value; }
        }

        private string templateName = "HtmlTemplate.htm";
        /// <summary>
        /// Template name, is the template file name
        /// </summary>
        public string TemplateName
        {
            set
            {
                if (string.IsNullOrEmpty(value) == false)
                    this.templateName = value;
            }
        }

        private string userName = "Sirs";
        /// <summary>
        /// Give the user name
        /// </summary>
        public string UserName
        {
            set { this.userName = value; }
        }

        private string title = "�q�l���۰��I��";
        /// <summary>
        /// The email title
        /// </summary>
        public string Title
        {
            set { this.title = value; }
        }

        #endregion

        /// <summary>
        /// constructor
        /// </summary>
        public HtmlTemplate(): this(string.Empty)
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// Constructor function
        /// </summary>
        /// <param name="templateName">the template name that is the template file name</param>
        public HtmlTemplate(string templateName)
        {
            if (string.IsNullOrEmpty(templateName) == true)
                templateName = "HtmlTemplate.htm";
            this.fileName = string.Format(@"{0}\Fabinfo\Template\{1}", System.AppDomain.CurrentDomain.BaseDirectory, templateName);
        }

        #region ITemplate Members
        /// <summary>
        /// Get the template text from given template name
        /// </summary>
        /// <param name="templateName"></param>
        /// <param name="reportFrequency"></param>
        /// <returns></returns>
        public string GetTemplate(string templateName, ReportFrequency reportFrequency)
        {
            try
            {
                string temp = FileHelper.ReadFile(this.fileName);
                temp.Replace("##UserName##", this.userName);
                temp.Replace("##CheckFrequency##", this.FrequencyToString(reportFrequency));
                temp.Replace("##DataSource##", this.DataTableToHtmalTable(this.dataSource));
                return temp;
            }
            catch (Exception ex)
            {
                throw new Exception("Operate the HtmlTemplate error: " + ex.Message);
            }
            //return string.Empty;
        }

        /// <summary>
        /// Get the Mail Subject to be sent in the mail
        /// </summary>
        /// <returns></returns>
        public string GetMailSubject()
        {
            return "";
        }

        #endregion

        #region Private function
        private string FrequencyToString(ReportFrequency frequency)
        {
            //string temp = "Check";
            //switch (frequency)
            //{
            //    case ReportFrequency.Hourly:
            //        temp = "Hourly_Check";

            //}
            return string.Format("{0}_Check", frequency);
        }
        private string DataTableToHtmalTable(DataTable dataSource)
        {
            string tableHeader = @"
<table style='font-family:Arial;' bordercolor =Black cellpadding='1' cellspacing='1'>
";
            string title = @"
	<tr bgcolor='#003366' style='color:White'>
		<td>&nbsp;REPORTID&nbsp;</td>
		<td>&nbsp;REPORTNAME&nbsp;</td>
		<td>&nbsp;STATUS&nbsp;</td>
		<td>&nbsp;RUNDATETIME&nbsp;</td>
		<td>&nbsp;MESSAGE&nbsp;</td>
	</tr>
";
            string tableButtom = @"    
</table>
";
            string content = string.Empty;

            if (dataSource == null || dataSource.Columns.Count < 1)
                return string.Format("{0}{1}{2}", tableHeader, title, content, tableButtom);

            title = @"<tr bgcolor='#003366' style='color:White'>";
            for (int i = 0; i < dataSource.Columns.Count; i++)
                title += string.Format("<td>&nbsp;{0}&nbsp;</td>", dataSource.Columns[i].ColumnName);
            title += "</tr>";

            for (int i = 0; i < dataSource.Rows.Count; i++)
            {
                content += "<tr>";
                for (int j = 0; j < dataSource.Columns.Count; j++)
                    content += string.Format("<td>{0}</td>", dataSource.Rows[i][j]);
                content += "</tr>";
            }

            return string.Format("{0}{1}{2}", tableHeader, title, content, tableButtom);
        }

        #endregion
    }
}