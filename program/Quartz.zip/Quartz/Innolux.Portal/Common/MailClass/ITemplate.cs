using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Innolux.Portal.Common.MailClass
{
    /// <summary>
    /// Template, define the Html, XML etc must be execute
    /// </summary>
    public interface ITemplate
    {
        string GetMailSubject();
        string GetTemplate(string templateName, ReportFrequency reportFrequency);
    }
}