using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Innolux.Portal.Common.MailClass
{
    /// <summary>
    /// Mail content format, change the mail to the format  
    /// </summary>
    public class MailFormat
    {
        public MailFormat()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// Convert the template to HTML string
        /// </summary>
        /// <returns>string</returns>
        public string ToHtml()
        {
            Template template = new Template();

            return "";
        }

        /// <summary>
        /// Convert the template XML string
        /// </summary>
        /// <returns></returns>
        public string ToXML()
        {
            return "";
        }
    } 
}