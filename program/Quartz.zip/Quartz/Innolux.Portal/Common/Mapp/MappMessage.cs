﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using System.Text;
using System.Net;
using Newtonsoft.Json;


namespace Innolux.Portal.Common.Mapp
{
    public enum RunMode { Production, Demo };
    public enum MessageType { TextMessage = 1, File = 2, Map = 3 };

    public abstract class MappMessage
    {
        protected RequestDTO requestDTO;

        //private static readonly RunMode ConstRunMode = RunMode.Demo;
        private static readonly RunMode ConstRunMode = RunMode.Production;
        private string url;

        public MappMessage(RequestDTO requestDTO)
        {
            this.requestDTO = requestDTO;
            url = (ConstRunMode == RunMode.Production) ? "http://mapp.innolux.com/teamplus_innolux/API/IMService.ashx" : "http://mapptest.innolux.com/teamplus_innolux/API/IMService.ashx";
        }

        public abstract ResponseDTO Send();

        protected string HttpRequestSubmit(Dictionary<string, string> postParameters)
        {
            string responseFromServer = string.Empty;
            string postData = string.Empty;

            foreach (string key in postParameters.Keys)
            {
                postData += HttpUtility.UrlEncode(key) + "="
                      + HttpUtility.UrlEncode(postParameters[key]) + "&";
            }

            byte[] bs = Encoding.ASCII.GetBytes(postData);

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = bs.Length;
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            using (Stream reqStream = request.GetRequestStream())
            {
                reqStream.Write(bs, 0, bs.Length);
            }

            using (WebResponse response = request.GetResponse())
            {
                //在這裡對接收到的頁面內容進行處理
                using (Stream dataStream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(dataStream))
                    {
                        responseFromServer = reader.ReadToEnd();
                    }
                }
            }

            return responseFromServer;
        }

        protected Dictionary<string, string> GetCommonParameter()
        {
            Dictionary<string, string> postParameters = new Dictionary<string, string>();
            postParameters.Add("ask", "sendChatMessage");
            postParameters.Add("account", requestDTO.Account);
            postParameters.Add("api_key", requestDTO.APIKey);
            postParameters.Add("chat_sn", requestDTO.ChatSn);
            postParameters.Add("content_type", ((int)requestDTO.ContentType).ToString());
            
            return postParameters;
        }

    }

    public class SendMessage : MappMessage
    {
        public SendMessage(RequestDTO requestDTO) : base(requestDTO) { }

        public override ResponseDTO Send()
        {
            try
            {
                Dictionary<string, string> postParameters = GetCommonParameter();

                postParameters.Add("msg_content", requestDTO.MsgContent);

                string response = HttpRequestSubmit(postParameters);

                ResponseDTO responseDTO = JsonConvert.DeserializeObject<ResponseDTO>(response);

                return responseDTO;
            }
            catch (Exception exception)
            {
                return new ResponseDTO { IsSuccess = false, Description = exception.ToString() }; 
            }
        }
    }

    public class SendFile : MappMessage
    {
        private string fileExtension;

        public SendFile(RequestDTO requestDTO) : base(requestDTO) { }

        public override ResponseDTO Send()
        {
            try
            {
                if (!File.Exists(requestDTO.FileName))
                    return new ResponseDTO { IsSuccess = false, Description = "Upload File is not exist" }; 
               
                if (!Path.HasExtension(requestDTO.FileName))
                    return new ResponseDTO { IsSuccess = false, Description = "Upload File does not have extension" }; 
               
                fileExtension = Path.GetExtension(requestDTO.FileName).Replace(".","");
                string base64 = ConvertToBase64(requestDTO.FileName);
                string uploadFileName = UploadFile(base64);

                Dictionary<string, string> postParameters = GetCommonParameter();

                postParameters.Add("msg_content", uploadFileName);

                //user有上傳file show name,將加上副檔名,若無就用上傳檔名
                if (string.IsNullOrEmpty(requestDTO.FileShowName))
                    postParameters.Add("file_show_name", Path.GetFileName(requestDTO.FileName));
                else
                    postParameters.Add("file_show_name", requestDTO.FileShowName + "." + fileExtension);

                string response = HttpRequestSubmit(postParameters);

                ResponseDTO responseDTO = JsonConvert.DeserializeObject<ResponseDTO>(response);

                return responseDTO;
            }
            catch (Exception exception)
            {
                return new ResponseDTO { IsSuccess = false, Description = exception.ToString() }; 
            }
        }

        private string ConvertToBase64(string fileName)
        {
            byte[] bytes = File.ReadAllBytes(fileName);
            string base64 = Convert.ToBase64String(bytes);
            return base64;
        }

        private string UploadFile(string base64)
        {
            Dictionary<string, string> postParameters = new Dictionary<string, string>();
            postParameters.Add("ask", "uploadFile");
            postParameters.Add("account", requestDTO.Account);
            postParameters.Add("api_key", requestDTO.APIKey);
            postParameters.Add("file_type", fileExtension);
            postParameters.Add("data_binary", base64);

            string response = HttpRequestSubmit(postParameters);

            UploadFile uploadFile = JsonConvert.DeserializeObject<UploadFile>(response);

            if (uploadFile.IsSuccess)
                return uploadFile.FileName;
            else
                throw new Exception(uploadFile.Description);
        }

    }

    public class RequestDTO
    {
        private string account;
        private string apiKey;
        private string chatSn;
        private MessageType contentType;
        private string msgContent;
        private string fileShowName;
        private string filename;

        //帳號
        public string Account
        {
            get { return this.account; }
            set { this.account = value; }
        }

        public string APIKey
        {
            get { return this.apiKey; }
            set { this.apiKey = value; }
        }

        //交談室 編號
        public string ChatSn
        {
            get { return this.chatSn; }
            set { this.chatSn = value; }
        }

        //訊息內容類別
        public MessageType ContentType
        {
            get { return this.contentType; }
            set { this.contentType = value; }
        }

        //訊息內容
        public string MsgContent
        {
            get { return this.msgContent; }
            set { this.msgContent = value; }
        }

        //檔案顯示名稱
        public string FileShowName
        {
            get { return this.fileShowName; }
            set { this.fileShowName = value; }
        }

        //要上傳的檔案名稱
        public string FileName
        {
            get { return this.filename; }
            set { this.filename = value; }
        }
    }

    public class ResponseDTO
    {
        private Boolean isSuccess;
        private string description;
        private int errorCode;
        private string batchID;
                
        //是否執行成功
        public Boolean IsSuccess
        {
            get { return this.isSuccess; }
            set { this.isSuccess = value; }
        }

        //成功或失敗之說明
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }

        //錯誤代碼
        public int ErrorCode
        {
            get { return this.errorCode; }
            set { this.errorCode = value; }
        }

        //本次發送訊息的批次代碼
        public string BatchID
        {
            get { return this.batchID; }
            set { this.batchID = value; }
        }
    }

    public class UploadFile
    {
        private Boolean isSuccess;
        private string description;
        private int errorCode;
        private string fileName;

        //是否執行成功
        public Boolean IsSuccess
        {
            get { return this.isSuccess; }
            set { this.isSuccess = value; }
        }

        //成功或失敗之說明
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }

        //錯誤代碼
        public int ErrorCode
        {
            get { return this.errorCode; }
            set { this.errorCode = value; }
        }

        //上傳成功後，Mapp給的檔案名稱
        public string FileName
        {
            get { return this.fileName; }
            set { this.fileName = value; }
        }
    }

    public class MappFactory
    {
        public static MappMessage CreateMappMessage(RequestDTO requestDTO)
        {
            switch (requestDTO.ContentType)
            {
                case MessageType.TextMessage:
                    return new SendMessage(requestDTO);
                case MessageType.File:
                    return new SendFile(requestDTO);
                default:
                    return new SendMessage(requestDTO);
            }
        }
    }
}