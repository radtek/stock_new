using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Innolux.Portal.Common.FileClass
{
    /// <summary>
    /// Summary description for Base
    /// </summary>
    public class Base
    {
        public Base()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string GetFileName(string strFile)
        {
            if (string.IsNullOrEmpty(strFile))
                return "";

            try
            {
                string strFilePath = "";
                string strFileName = "";
                if (strFile.Length > 0)
                {
                    if (strFile.Substring(strFile.Length - 1, 1) == "\\")
                        strFilePath = strFile.Substring(0, strFile.Length - 1);
                    else
                        strFilePath = strFile;

                    int intPos = strFilePath.LastIndexOf("\\");
                    if (intPos > 0)
                        strFileName = strFilePath.Substring(intPos + 1, strFilePath.Length - intPos - 1);
                    else
                        strFileName = strFilePath;

                    if (strFileName.IndexOf(".") > 0)
                        strFileName = strFileName.Substring(0, strFileName.IndexOf("."));
                }
                return (strFileName);
            }
            catch
            {
                return "";
            }
        }

        public string GetFileExtraName(string strFile)
        {
            if (string.IsNullOrEmpty(strFile))
                return "";

            try
            {
                string strFilePath = "";
                string strFileExtra = "";
                if (strFile.Length > 0)
                {
                    if (strFile.Substring(strFile.Length - 1, 1) == "\\")
                        strFilePath = strFile.Substring(0, strFile.Length - 1);
                    else
                        strFilePath = strFile;
                    
                    int intPos = strFilePath.LastIndexOf(".");
                    if (intPos > 0)
                        strFileExtra = strFilePath.Substring(intPos + 1, strFilePath.Length - intPos - 1);
                    else
                        strFileExtra = strFilePath;
                }
                return strFileExtra;
            }
            catch
            {
                return "";
            }
        }

        public string GetFilePath(string strFile)
        {
            try
            {
                string strFilePath = "";
                string strFileFolder = "";
                if (strFile.Length > 0)
                {
                    if (strFile.Substring(strFile.Length - 1, 1) == "\\")
                        strFilePath = strFile.Substring(0, strFile.Length - 1);
                    else
                        strFilePath = strFile;
                    
                    int intPos = strFilePath.LastIndexOf("\\");
                    if (intPos > 0)
                        strFileFolder = strFilePath.Substring(0, intPos);
                    else
                        strFileFolder = strFilePath;
                }
                return strFileFolder;
            }
            catch
            {
                return "";
            }
        }
    }
}
