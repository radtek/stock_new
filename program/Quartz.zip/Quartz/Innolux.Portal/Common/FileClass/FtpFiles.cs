using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Innolux.Portal.Common.FileClass
{

    /// <summary>
    /// Summary description for FtpFiles
    /// </summary>
    public class FtpFiles
    {
        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
        }

        private string server = string.Empty;
        public string Server
        {
            get { return this.server; }
            set { this.server = value; }
        }

        private string user = string.Empty;
        public string User
        {
            get { return this.user; }
            set { this.user = value; }
        }

        private string password = string.Empty;
        public string Password
        {
            get { return this.password; }
            set { this.password = value; }
        }

        private string ftpPath = string.Empty;
        public string FtpPath
        {
            get { return this.ftpPath; }
            set { this.ftpPath = value; }
        }


        public FtpFiles()
        {
            //
            // TODO: Add constructor logic here
            //
            Settings.AssemblySettings asm = new Settings.AssemblySettings();
            this.errorMessage = string.Empty;
            this.server = asm["FTP_SERVER"];
            this.user = asm["FTP_USER"];
            this.password = asm["FTP_PWD"];
            this.ftpPath = asm["FTP_DIR"]; 
        }

        public FtpFiles(string server, string user, string password)
        {
            this.server = server;
            this.user = user;
            this.password = password;
        }

        public bool FtpUpload(string uploadFile, string serverPath)
        {
            this.ftpPath = serverPath;
            return this.FtpUpload(uploadFile);
        }

        public bool FtpUpload(string uploadFile)
        {
            if (string.IsNullOrEmpty(uploadFile))
                return true;
            // 
            FtpFactory ftp = new FtpFactory();
            ftp.setRemoteHost(this.server);
            ftp.setRemoteUser(this.user);
            ftp.setRemotePass(this.password);
            try
            {
                ftp.login();
                if (ftp == null)
                    return false;
                ftp.chdir(this.ftpPath);
                ftp.setBinaryMode(true);
                ftp.upload(uploadFile);
                ftp.close();
            }
            catch (Exception ex)
            {
                this.errorMessage = ex.Message;
                return false;
            }
            return true;
        }


        public bool FtpDownload(string downloadFile, string clientPath)
        {
            return this.FtpDownload(downloadFile, clientPath, "/");
        }

        public bool FtpDownload(string downloadFile, string clientPath, string serverPath)
        {
            if (string.IsNullOrEmpty(downloadFile))
                return true;
            if (string.IsNullOrEmpty(serverPath))
                serverPath = this.ftpPath;
            this.ftpPath = serverPath;
            // 
            FtpFactory ftp = new FtpFactory();
            ftp.setRemoteHost(this.server);
            ftp.setRemoteUser(this.user);
            ftp.setRemotePass(this.password);
            try
            {
                ftp.login();
                if (ftp == null)
                    return false;
                ftp.chdir(serverPath);
                ftp.setBinaryMode(true);
                ftp.download(downloadFile, clientPath + Path.DirectorySeparatorChar + downloadFile);
                ftp.close();
            }
            catch (Exception ex)
            {
                this.errorMessage = ex.Message;
                return false;
            }
            return true;
        }
    }
}