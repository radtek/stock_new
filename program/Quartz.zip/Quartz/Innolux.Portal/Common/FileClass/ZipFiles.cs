﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ionic.Zip;
using System.Collections;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;

namespace Innolux.Portal.Common.FileClass
{
    public class ZipFiles
    {
        //讀取目錄下所有檔案
        private static ArrayList GetFiles(string path)
        {
            ArrayList files = new ArrayList();

            if (Directory.Exists(path))
            {
                files.AddRange(Directory.GetFiles(path, "*.*", System.IO.SearchOption.AllDirectories));
            }

            return files;
        }

        //壓縮檔案
        //path: 壓縮檔案路徑
        //dirType:0:full,1:partial,2:empty
        public static void IonicZip(string path,int dirType)
        {
            string zipPath = path + @"\" + Path.GetFileName(path) + ".zip";
            Ionic.Zip.ZipFile zip = new Ionic.Zip.ZipFile();
            ArrayList files = GetFiles(path);

            foreach (string f in files)
            {
                if (dirType == 0)
                    zip.AddFile(f);
                else if (dirType == 1)
                {
                    FileInfo fileInf = new FileInfo(f);
                    string partialDir = f.Replace(path + "\\", "");
                    partialDir = partialDir.Replace(fileInf.Name, "");
                    zip.AddFile(f, partialDir);//第二個參數設為空值表示壓縮檔案時不將檔案路徑加入
                }
                else
                    zip.AddFile(f, string.Empty);
            }
            zip.Save(zipPath);
        }

        //壓縮檔案
        //path: 壓縮檔案路徑
        //dirType:0:full,1:partial
        public static void SharpZip(string path, int dirType)
        {
            string zipPath = path + @"\" + Path.GetFileName(path) + ".zip";
            ArrayList files = GetFiles(path);
            byte[] buffer = new byte[4096];

            using (ICSharpCode.SharpZipLib.Zip.ZipOutputStream s = new ICSharpCode.SharpZipLib.Zip.ZipOutputStream(File.Create(zipPath)))
            {
                // 設定壓縮比
                s.SetLevel(9);

                // 逐一將資料夾內的檔案抓出來壓縮，並寫入至目的檔(.ZIP)
                foreach (string f in files)
                {
                    ICSharpCode.SharpZipLib.Zip.ZipEntry entry; 
                    if (dirType==0)
                        entry = new ICSharpCode.SharpZipLib.Zip.ZipEntry(f);
                    else
                        entry = new ICSharpCode.SharpZipLib.Zip.ZipEntry(f.Replace(path + "\\", ""));
                    s.PutNextEntry(entry);

                    using (FileStream fs = File.OpenRead(f))
                        StreamUtils.Copy(fs, s, buffer);
                }
            }
        }

        public static void ZipExe(string path)
        {
            string zipPath = path + @"\" + Path.GetFileName(path) + ".zip";
            //64位元
            if (IntPtr.Size ==8)
                System.Diagnostics.Process.Start("7z.exe", string.Format(@"  a -tzip {1} {0}\*", path, zipPath)).WaitForExit();
            else
                System.Diagnostics.Process.Start("7z32.exe", string.Format(@"  a -tzip {1} {0}\*", path, zipPath)).WaitForExit();
        }
    }
}
