﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;


namespace Innolux.Portal.Common.Settings
{
    class AssemblySettings
    {
        private KeyValueConfigurationCollection settings;

        public AssemblySettings()
        {
            LoadSettings(System.Reflection.Assembly.GetExecutingAssembly());
        }

        private void LoadSettings(System.Reflection.Assembly asmb)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(asmb.Location);

            AppSettingsSection section = (config.GetSection("appSettings") as AppSettingsSection);
            settings = section.Settings;
        }

        public string this[string key]
        {
            get
            {
                return settings[key].Value;
            }
        }
    }
}
