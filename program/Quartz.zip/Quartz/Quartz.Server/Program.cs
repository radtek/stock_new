﻿using System.IO;
using Topshelf;
using Quartz.CustomJob.Job.EDA;
using System;

namespace Quartz.Server
{
    /// <summary>
    /// The server's main entry point.
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Main.
        /// </summary>
        public static void Main()
        {
            //Console.WriteLine("Begin:" + DateTime.Now.ToString());
            //ArrayDefectToMQFileAndPushToFtp test = new ArrayDefectToMQFileAndPushToFtp("T1ARRAY", "TT09", "TFTR2", "20171026");
            //test.Execute();
            //Console.WriteLine("End:" + DateTime.Now.ToString());
            //Console.ReadKey();
            // change from service account's dir to more logical one
            Directory.SetCurrentDirectory(System.AppDomain.CurrentDomain.BaseDirectory);

            HostFactory.Run(x =>
                                {
                                    x.RunAsLocalSystem();

                                    x.SetDescription(Configuration.ServiceDescription);
                                    x.SetDisplayName(Configuration.ServiceDisplayName);
                                    x.SetServiceName(Configuration.ServiceName);

                                    x.Service(factory =>
                                                  {
                                                      QuartzServer server = QuartzServerFactory.CreateServer();
                                                      server.Initialize();
                                                      return server;
                                                  });
                                });
        }
    }
}