﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Xml;
using System.Xml.Linq;
using System.Diagnostics;

namespace Quartz.JobConfig
{
    public partial class JobConfig : Form
    {
        private string fileDirectoty;
        private string fileImportName;
        private DataTable table = new DataTable();
        private static readonly string xmlConfigLoc = System.AppDomain.CurrentDomain.BaseDirectory + "quartz_jobs.xml";
        public JobConfig()
        {
            InitializeComponent();
        }

        private void JobConfig_Load(object sender, EventArgs e)
        {
            SetGridViewImageColumn(dgTriggerList, "Delete", 0);
            table.Columns.Add("Trigger Name");
            table.Columns.Add("Job Name");
            table.Columns.Add("Job Group");
            table.Columns.Add("Trigger Type");
            table.Columns.Add("Interval(sec.)/Cron Expression");
            table.Columns.Add("Description");
            dgTriggerList.DataSource = table;
            
            if (IsProcessOpen("Quartz.Server"))
            {
                lblScheduleStatus.Text = "Running...";
                lblScheduleStatus.ForeColor = Color.ForestGreen;
                btnAction.BackgroundImage = Quartz.JobConfig.Properties.Resources.pause;
            }
            else
            {
                lblScheduleStatus.Text = "Stop...";
                lblScheduleStatus.ForeColor = Color.Red;
                btnAction.BackgroundImage = Quartz.JobConfig.Properties.Resources.play;
            }
        }
        private bool IsProcessOpen(string name)
        {           
            foreach (Process clsProcess in Process.GetProcesses())
            {
                if (clsProcess.ProcessName.Contains(name))
                {
                    return true;
                }
            }
            return false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openJobFileDialog = new OpenFileDialog();
            openJobFileDialog.Filter = "DLL file(*.dll)|*.dll";
            openJobFileDialog.FilterIndex = 1;
            openJobFileDialog.RestoreDirectory = true;

            if (openJobFileDialog.ShowDialog() == DialogResult.OK)
            {
                allJobComBox.Items.Clear();
                this.txtFileToImport.Text = openJobFileDialog.FileName.ToString();
                this.fileImportName = openJobFileDialog.SafeFileName;
                this.fileDirectoty = openJobFileDialog.FileName.Replace(this.fileImportName, "");
                Assembly jobAssembly;
                jobAssembly = Assembly.LoadFrom(openJobFileDialog.FileName);
                foreach (Type tp in jobAssembly.GetTypes())
                {
                    try
                    {
                        if (tp.BaseType.Name.Equals("JobBsae"))
                        {
                            //allJobList.Items.Add(new JobItem(tp.Name, tp.FullName, tp.Namespace));
                            allJobComBox.Items.Add(new JobItem(tp.Name, tp.FullName, tp.Assembly.GetName().Name));
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Please Choose Job Library !!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                    
                }
                allJobComBox.DisplayMember = "FullName";
                allJobComBox.ValueMember = "Namespace";
            }
        }

        private void allJobComBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListJobTriggerInfo();
        }

        private void ListJobTriggerInfo()
        {
            table.Rows.Clear();
            string jobName = ((JobItem)allJobComBox.SelectedItem).Fullname;
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(xmlConfigLoc);

            // Add the namespace.
            XmlNamespaceManager nsm = new XmlNamespaceManager(XmlDoc.NameTable);
            //nsm.AddNamespace("x", @"http://www.w3.org/2001/XMLSchema-instance");
            nsm.AddNamespace("x", @"http://quartznet.sourceforge.net/JobSchedulingData");

            XmlNodeList NodeLists = XmlDoc.SelectNodes(string.Format("/x:job-scheduling-data/x:schedule/x:trigger/x:cron[x:job-name='{0}']", jobName), nsm);
            //XmlNodeList NodeLists = XmlDoc.SelectNodes("/y:job-scheduling-data/y:schedule/y:trigger/y:cron", nsm);


            foreach (XmlNode OneNode in NodeLists)
            {
                table.Rows.Add(new object[] { OneNode.ChildNodes[0].InnerText, 
                                              OneNode.ChildNodes[3].InnerText, 
                                              OneNode.ChildNodes[4].InnerText, 
                                              "Cron", 
                                              OneNode.ChildNodes[5].InnerText,
                                              OneNode.ChildNodes[2].InnerText});
            }
            NodeLists = XmlDoc.SelectNodes(string.Format("/x:job-scheduling-data/x:schedule/x:trigger/x:simple[x:job-name='{0}']", jobName), nsm);
            foreach (XmlNode OneNode in NodeLists)
            {
                table.Rows.Add(new object[] { OneNode.ChildNodes[0].InnerText, 
                                              OneNode.ChildNodes[3].InnerText, 
                                              OneNode.ChildNodes[4].InnerText, 
                                              "Simple", 
                                              OneNode.ChildNodes[7].InnerText,
                                              OneNode.ChildNodes[2].InnerText});
            }
            dgTriggerList.DataSource = table;
            dgTriggerList.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgTriggerList.Columns[1].Visible = false;
        }

        private void btnTriggerSave_Click(object sender, EventArgs e)
        {
            JobItem jobItem = (JobItem)allJobComBox.SelectedItem;
            string triggerfreq =  ((Button)sender).Parent.Text;
            if ((allJobComBox.Items.Count > 0) && (allJobComBox.SelectedItem != null))
            {
                AddJob(jobItem);
                AddJobTrigger(jobItem, triggerfreq.Equals("Min") ? "simple" : "cron", triggerfreq);
                ListJobTriggerInfo();
            }
            else
                MessageBox.Show("Please Select a Job !!!","Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        private void AddJob(JobItem jobItem)
        {
            XDocument xdoc = XDocument.Load(xmlConfigLoc);
            XNamespace xname = xdoc.Root.GetDefaultNamespace();
            int jobCount = xdoc.Root.Element(xname + "schedule").Elements(xname + "job").Descendants(xname + "name").Count(x => x.Value == jobItem.Fullname);
            if (jobCount == 0)
            {
                XElement xmlJob = new XElement(xname+"job",
                                  new XElement(xname+"name", jobItem.Fullname),
                                  new XElement(xname + "group", jobItem.Name),
                                  new XElement(xname + "description", ""),
                                  new XElement(xname + "job-type", jobItem.Fullname + ", " + jobItem.Namespaces),
                                  new XElement(xname + "durable", "true"),
                                  new XElement(xname + "recover", "false"));
                xdoc.Root.Element(xname + "schedule").Add(xmlJob);
                xdoc.Save(xmlConfigLoc);
            }
        }
        private void AddJobTrigger(JobItem jobItem, string triggerType, string triggerfreq)
        {
            DialogResult dialogResult = MessageBox.Show("Add This Job Trigger ???", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.OK)
            {
                XDocument xdoc = XDocument.Load(xmlConfigLoc);
                XNamespace xname = xdoc.Root.GetDefaultNamespace();
                XElement xmlJob;
                if (triggerType.Equals("simple"))
                {
                    xmlJob = new XElement(xname + "trigger",
                                    new XElement(xname + triggerType,
                                          new XElement(xname + "name", jobItem.Name + "_" + System.DateTime.Now.ToString("yyMMddHHmmss")),
                                          new XElement(xname + "group", jobItem.Name),
                                          new XElement(xname + "description", txtMinDes.Text),
                                          new XElement(xname + "job-name", jobItem.Fullname),
                                          new XElement(xname + "job-group", jobItem.Name),
                                          new XElement(xname + "misfire-instruction", "SmartPolicy"),
                                          new XElement(xname + "repeat-count", numericRepeat.Value.ToString()),
                                          new XElement(xname + "repeat-interval", (numericInterval.Value * 60 * 1000).ToString())
                                          ));
                }
                else
                {
                    string cronExpress, desc = string.Empty;
                    if (triggerfreq.Equals("Day"))
                    {
                        desc = txtDayDes.Text;
                        cronExpress = "0 " + minComBoxDay.SelectedItem.ToString() + " " + hourComBoxDay.SelectedItem.ToString() + " ? * *";
                    }
                    else if (triggerfreq.Equals("Week"))
                    {
                        desc = txtWeekDes.Text;
                        cronExpress = "0 " + minComBoxWeek.SelectedItem.ToString() + " " + hourComBoxWeek.SelectedItem.ToString() + " ? * " + weekComBox.SelectedItem.ToString();
                    }
                    else
                    {
                        desc = txtMonthDes.Text;
                        cronExpress = "0 " + minComBoxMonth.SelectedItem.ToString() + " " + hourComBoxMonth.SelectedItem.ToString() + " " + dayComBox.SelectedItem.ToString() + " * ?";
                    }
                    xmlJob = new XElement(xname + "trigger",
                                    new XElement(xname + triggerType,
                                          new XElement(xname + "name", jobItem.Name + "_" + System.DateTime.Now.ToString("yyMMddHHmmss")),
                                          new XElement(xname + "group", jobItem.Name),
                                          new XElement(xname + "description", desc),
                                          new XElement(xname + "job-name", jobItem.Fullname),
                                          new XElement(xname + "job-group", jobItem.Name),
                                          new XElement(xname + "cron-expression", cronExpress)
                                          ));
                }
                xdoc.Root.Element(xname + "schedule").Add(xmlJob);

                xdoc.Save(xmlConfigLoc);
            }
        }

        private void dgTriggerList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 0)
            {
                DialogResult dialogResult = MessageBox.Show("Delete This Job Trigger ???", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.OK)
                {
                    string triName = dgTriggerList["Trigger Name", e.RowIndex].Value.ToString();
                    string triType = dgTriggerList["Trigger Type", e.RowIndex].Value.ToString();
                    XDocument xdoc = XDocument.Load(xmlConfigLoc);
                    XNamespace xname = xdoc.Root.GetDefaultNamespace();
                    xdoc.Root.Element(xname + "schedule")
                             .Elements(xname + "trigger")
                                     .Descendants(xname + triType.ToLower())
                                     .Single(x => x.Element(xname+"name").Value == triName)
                                     .Parent.Remove();
                    xdoc.Save(xmlConfigLoc);

                    ListJobTriggerInfo();
                }
                    
            
            }
        }
        public void SetGridViewImageColumn(DataGridView dgv, string tooltip, int colIndex)
        {
            DataGridViewImageColumn imgCol = new DataGridViewImageColumn();
            imgCol.Width = 25;
            imgCol.CellTemplate.ToolTipText = tooltip;
            imgCol.HeaderText = tooltip;
            imgCol.Name = tooltip;
            imgCol.Image = Quartz.JobConfig.Properties.Resources.delete;

            if (colIndex == -1)
                dgv.Columns.Add(imgCol);
            else
                dgv.Columns.Insert(colIndex, imgCol);
        }

        private void btnAction_Click(object sender, EventArgs e)
        {
            try
            {
                if (!lblScheduleStatus.Text.Contains("Running"))
                {
                    Process p = new Process();
                    p.StartInfo.FileName = System.AppDomain.CurrentDomain.BaseDirectory +"Quartz.Server.exe";
                    p.Start();
                    btnAction.BackgroundImage = Quartz.JobConfig.Properties.Resources.pause;
                    lblScheduleStatus.Text = "Running...";
                }
                else
                {
                    foreach (Process clsProcess in Process.GetProcesses())
                    {
                        if (clsProcess.ProcessName.Contains("Quartz.Server"))
                        {
                            clsProcess.Kill();
                        }
                    }
                    btnAction.BackgroundImage = Quartz.JobConfig.Properties.Resources.play;
                    lblScheduleStatus.Text = "Stop...";
                }

            }
            catch
            {
                MessageBox.Show("Run Schedule Fail !!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
    public class JobItem
    {
        private string name;
        private string fullname;
        private string namespaces;

        public JobItem(string strName, string strFullName, string strNamespaces)
        {
            this.name = strName;
            this.fullname = strFullName;
            this.namespaces = strNamespaces;
        }
        public string Name
        {
            get { return name; }
        }
        public string Fullname
        {
            get { return fullname; }
        }
        public string Namespaces
        {
            get { return namespaces; }
        }
    }
}
