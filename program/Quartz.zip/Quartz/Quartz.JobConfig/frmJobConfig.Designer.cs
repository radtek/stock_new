﻿namespace Quartz.JobConfig
{
    partial class JobConfig
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JobConfig));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAction = new System.Windows.Forms.Button();
            this.lblScheduleStatus = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgTriggerList = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabTrigger = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnMinSave = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numericRepeat = new System.Windows.Forms.NumericUpDown();
            this.numericInterval = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMinDes = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnDaySave = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.minComBoxDay = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDayDes = new System.Windows.Forms.TextBox();
            this.hourComBoxDay = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnWeekSave = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.minComBoxWeek = new System.Windows.Forms.ComboBox();
            this.hourComBoxWeek = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.weekComBox = new System.Windows.Forms.ComboBox();
            this.txtWeekDes = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnMonthSave = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.hourComBoxMonth = new System.Windows.Forms.ComboBox();
            this.minComBoxMonth = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dayComBox = new System.Windows.Forms.ComboBox();
            this.txtMonthDes = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.allJobComBox = new System.Windows.Forms.ComboBox();
            this.txtFileToImport = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTriggerList)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabTrigger.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericRepeat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericInterval)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAction);
            this.groupBox1.Controls.Add(this.lblScheduleStatus);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(792, 52);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Schedule Server";
            // 
            // btnAction
            // 
            this.btnAction.BackgroundImage = global::Quartz.JobConfig.Properties.Resources.play;
            this.btnAction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAction.Location = new System.Drawing.Point(407, 23);
            this.btnAction.Name = "btnAction";
            this.btnAction.Size = new System.Drawing.Size(20, 20);
            this.btnAction.TabIndex = 2;
            this.btnAction.UseVisualStyleBackColor = true;
            this.btnAction.Click += new System.EventHandler(this.btnAction_Click);
            // 
            // lblScheduleStatus
            // 
            this.lblScheduleStatus.AutoSize = true;
            this.lblScheduleStatus.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScheduleStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblScheduleStatus.Location = new System.Drawing.Point(309, 19);
            this.lblScheduleStatus.Name = "lblScheduleStatus";
            this.lblScheduleStatus.Size = new System.Drawing.Size(82, 23);
            this.lblScheduleStatus.TabIndex = 1;
            this.lblScheduleStatus.Text = "Running";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(112, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(191, 18);
            this.label18.TabIndex = 0;
            this.label18.Text = "Current Scheduler State :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgTriggerList);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 383);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(792, 190);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Trigger List";
            // 
            // dgTriggerList
            // 
            this.dgTriggerList.AllowUserToAddRows = false;
            this.dgTriggerList.AllowUserToDeleteRows = false;
            this.dgTriggerList.AllowUserToOrderColumns = true;
            this.dgTriggerList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgTriggerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTriggerList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgTriggerList.Location = new System.Drawing.Point(3, 18);
            this.dgTriggerList.Name = "dgTriggerList";
            this.dgTriggerList.ReadOnly = true;
            this.dgTriggerList.RowTemplate.Height = 24;
            this.dgTriggerList.Size = new System.Drawing.Size(786, 169);
            this.dgTriggerList.TabIndex = 0;
            this.dgTriggerList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTriggerList_CellClick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tabTrigger);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 101);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(792, 282);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Config";
            // 
            // tabTrigger
            // 
            this.tabTrigger.Controls.Add(this.tabPage1);
            this.tabTrigger.Controls.Add(this.tabPage3);
            this.tabTrigger.Controls.Add(this.tabPage2);
            this.tabTrigger.Controls.Add(this.tabPage4);
            this.tabTrigger.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabTrigger.Location = new System.Drawing.Point(3, 18);
            this.tabTrigger.Name = "tabTrigger";
            this.tabTrigger.SelectedIndex = 0;
            this.tabTrigger.Size = new System.Drawing.Size(786, 261);
            this.tabTrigger.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnMinSave);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(778, 236);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Min";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnMinSave
            // 
            this.btnMinSave.Location = new System.Drawing.Point(698, 210);
            this.btnMinSave.Name = "btnMinSave";
            this.btnMinSave.Size = new System.Drawing.Size(75, 23);
            this.btnMinSave.TabIndex = 1;
            this.btnMinSave.Text = "Save";
            this.btnMinSave.UseVisualStyleBackColor = true;
            this.btnMinSave.Click += new System.EventHandler(this.btnTriggerSave_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.68831F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.31169F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.numericRepeat, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.numericInterval, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtMinDes, 1, 2);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(772, 204);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 66);
            this.label2.TabIndex = 8;
            this.label2.Text = "Description";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 65);
            this.label5.TabIndex = 3;
            this.label5.Text = "Repeat Count";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numericRepeat
            // 
            this.numericRepeat.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.numericRepeat.Location = new System.Drawing.Point(326, 90);
            this.numericRepeat.Maximum = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            this.numericRepeat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numericRepeat.Name = "numericRepeat";
            this.numericRepeat.Size = new System.Drawing.Size(69, 22);
            this.numericRepeat.TabIndex = 4;
            this.numericRepeat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericRepeat.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // numericInterval
            // 
            this.numericInterval.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.numericInterval.Location = new System.Drawing.Point(326, 23);
            this.numericInterval.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericInterval.Name = "numericInterval";
            this.numericInterval.Size = new System.Drawing.Size(69, 22);
            this.numericInterval.TabIndex = 7;
            this.numericInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericInterval.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Interval Minutes";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMinDes
            // 
            this.txtMinDes.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMinDes.Location = new System.Drawing.Point(326, 158);
            this.txtMinDes.Name = "txtMinDes";
            this.txtMinDes.Size = new System.Drawing.Size(157, 22);
            this.txtMinDes.TabIndex = 9;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnDaySave);
            this.tabPage3.Controls.Add(this.tableLayoutPanel2);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(778, 236);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Day";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnDaySave
            // 
            this.btnDaySave.Location = new System.Drawing.Point(698, 210);
            this.btnDaySave.Name = "btnDaySave";
            this.btnDaySave.Size = new System.Drawing.Size(75, 23);
            this.btnDaySave.TabIndex = 2;
            this.btnDaySave.Text = "Save";
            this.btnDaySave.UseVisualStyleBackColor = true;
            this.btnDaySave.Click += new System.EventHandler(this.btnTriggerSave_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.68831F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.31169F));
            this.tableLayoutPanel2.Controls.Add(this.minComBoxDay, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtDayDes, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.hourComBoxDay, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(778, 207);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // minComBoxDay
            // 
            this.minComBoxDay.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.minComBoxDay.FormattingEnabled = true;
            this.minComBoxDay.Items.AddRange(new object[] {
            "0",
            "5",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.minComBoxDay.Location = new System.Drawing.Point(328, 91);
            this.minComBoxDay.Name = "minComBoxDay";
            this.minComBoxDay.Size = new System.Drawing.Size(121, 24);
            this.minComBoxDay.TabIndex = 11;
            this.minComBoxDay.Text = "0";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 67);
            this.label6.TabIndex = 9;
            this.label6.Text = "Description";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 66);
            this.label7.TabIndex = 2;
            this.label7.Text = "Hour of Day";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 66);
            this.label3.TabIndex = 8;
            this.label3.Text = "Min. of Hour";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDayDes
            // 
            this.txtDayDes.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDayDes.Location = new System.Drawing.Point(328, 160);
            this.txtDayDes.Name = "txtDayDes";
            this.txtDayDes.Size = new System.Drawing.Size(157, 22);
            this.txtDayDes.TabIndex = 7;
            // 
            // hourComBoxDay
            // 
            this.hourComBoxDay.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.hourComBoxDay.FormattingEnabled = true;
            this.hourComBoxDay.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.hourComBoxDay.Location = new System.Drawing.Point(328, 25);
            this.hourComBoxDay.Name = "hourComBoxDay";
            this.hourComBoxDay.Size = new System.Drawing.Size(121, 24);
            this.hourComBoxDay.TabIndex = 10;
            this.hourComBoxDay.Text = "0";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnWeekSave);
            this.tabPage2.Controls.Add(this.tableLayoutPanel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(778, 236);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "Week";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnWeekSave
            // 
            this.btnWeekSave.Location = new System.Drawing.Point(698, 210);
            this.btnWeekSave.Name = "btnWeekSave";
            this.btnWeekSave.Size = new System.Drawing.Size(75, 23);
            this.btnWeekSave.TabIndex = 3;
            this.btnWeekSave.Text = "Save";
            this.btnWeekSave.UseVisualStyleBackColor = true;
            this.btnWeekSave.Click += new System.EventHandler(this.btnTriggerSave_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.68831F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.31169F));
            this.tableLayoutPanel4.Controls.Add(this.minComBoxWeek, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.hourComBoxWeek, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label14, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label15, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.weekComBox, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.txtWeekDes, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel4.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(772, 205);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // minComBoxWeek
            // 
            this.minComBoxWeek.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.minComBoxWeek.FormattingEnabled = true;
            this.minComBoxWeek.Items.AddRange(new object[] {
            "0",
            "5",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.minComBoxWeek.Location = new System.Drawing.Point(326, 66);
            this.minComBoxWeek.Name = "minComBoxWeek";
            this.minComBoxWeek.Size = new System.Drawing.Size(121, 24);
            this.minComBoxWeek.TabIndex = 12;
            this.minComBoxWeek.Text = "0";
            // 
            // hourComBoxWeek
            // 
            this.hourComBoxWeek.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.hourComBoxWeek.FormattingEnabled = true;
            this.hourComBoxWeek.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.hourComBoxWeek.Location = new System.Drawing.Point(326, 16);
            this.hourComBoxWeek.Name = "hourComBoxWeek";
            this.hourComBoxWeek.Size = new System.Drawing.Size(121, 24);
            this.hourComBoxWeek.TabIndex = 11;
            this.hourComBoxWeek.Text = "0";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 102);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 48);
            this.label14.TabIndex = 2;
            this.label14.Text = "Day of Week";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 152);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 51);
            this.label15.TabIndex = 3;
            this.label15.Text = "Description";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // weekComBox
            // 
            this.weekComBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.weekComBox.FormattingEnabled = true;
            this.weekComBox.Items.AddRange(new object[] {
            "MON",
            "TUE",
            "WED",
            "THU",
            "FRI",
            "SAT",
            "SUN"});
            this.weekComBox.Location = new System.Drawing.Point(326, 114);
            this.weekComBox.Name = "weekComBox";
            this.weekComBox.Size = new System.Drawing.Size(90, 24);
            this.weekComBox.TabIndex = 7;
            this.weekComBox.Text = "MON";
            // 
            // txtWeekDes
            // 
            this.txtWeekDes.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtWeekDes.Location = new System.Drawing.Point(326, 166);
            this.txtWeekDes.Name = "txtWeekDes";
            this.txtWeekDes.Size = new System.Drawing.Size(157, 22);
            this.txtWeekDes.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "Hour of Day";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 16);
            this.label9.TabIndex = 10;
            this.label9.Text = "Min. of Hour";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnMonthSave);
            this.tabPage4.Controls.Add(this.tableLayoutPanel3);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(778, 236);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Month";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnMonthSave
            // 
            this.btnMonthSave.Location = new System.Drawing.Point(698, 210);
            this.btnMonthSave.Name = "btnMonthSave";
            this.btnMonthSave.Size = new System.Drawing.Size(75, 23);
            this.btnMonthSave.TabIndex = 4;
            this.btnMonthSave.Text = "Save";
            this.btnMonthSave.UseVisualStyleBackColor = true;
            this.btnMonthSave.Click += new System.EventHandler(this.btnTriggerSave_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.68831F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.31169F));
            this.tableLayoutPanel3.Controls.Add(this.hourComBoxMonth, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.minComBoxMonth, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label13, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.dayComBox, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtMonthDes, 1, 3);
            this.tableLayoutPanel3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(772, 206);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // hourComBoxMonth
            // 
            this.hourComBoxMonth.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.hourComBoxMonth.FormattingEnabled = true;
            this.hourComBoxMonth.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.hourComBoxMonth.Location = new System.Drawing.Point(326, 16);
            this.hourComBoxMonth.Name = "hourComBoxMonth";
            this.hourComBoxMonth.Size = new System.Drawing.Size(121, 24);
            this.hourComBoxMonth.TabIndex = 13;
            this.hourComBoxMonth.Text = "0";
            // 
            // minComBoxMonth
            // 
            this.minComBoxMonth.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.minComBoxMonth.FormattingEnabled = true;
            this.minComBoxMonth.Items.AddRange(new object[] {
            "0",
            "5",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.minComBoxMonth.Location = new System.Drawing.Point(326, 67);
            this.minComBoxMonth.Name = "minComBoxMonth";
            this.minComBoxMonth.Size = new System.Drawing.Size(121, 24);
            this.minComBoxMonth.TabIndex = 12;
            this.minComBoxMonth.Text = "0";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 16);
            this.label13.TabIndex = 11;
            this.label13.Text = "Min. of Hour";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 16);
            this.label12.TabIndex = 10;
            this.label12.Text = "Hour of Day";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 104);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 49);
            this.label10.TabIndex = 2;
            this.label10.Text = "Day of Month";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 155);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 49);
            this.label11.TabIndex = 3;
            this.label11.Text = "Description";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dayComBox
            // 
            this.dayComBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dayComBox.FormattingEnabled = true;
            this.dayComBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.dayComBox.Location = new System.Drawing.Point(326, 116);
            this.dayComBox.Name = "dayComBox";
            this.dayComBox.Size = new System.Drawing.Size(90, 24);
            this.dayComBox.TabIndex = 7;
            this.dayComBox.Text = "1";
            // 
            // txtMonthDes
            // 
            this.txtMonthDes.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMonthDes.Location = new System.Drawing.Point(326, 168);
            this.txtMonthDes.Name = "txtMonthDes";
            this.txtMonthDes.Size = new System.Drawing.Size(157, 22);
            this.txtMonthDes.TabIndex = 8;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.allJobComBox);
            this.groupBox4.Controls.Add(this.txtFileToImport);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.btnBrowse);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(0, 52);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(792, 49);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Job";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(431, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 12);
            this.label17.TabIndex = 10;
            this.label17.Text = "Job List :";
            // 
            // allJobComBox
            // 
            this.allJobComBox.FormattingEnabled = true;
            this.allJobComBox.Location = new System.Drawing.Point(489, 16);
            this.allJobComBox.Name = "allJobComBox";
            this.allJobComBox.Size = new System.Drawing.Size(269, 20);
            this.allJobComBox.TabIndex = 9;
            this.allJobComBox.SelectedIndexChanged += new System.EventHandler(this.allJobComBox_SelectedIndexChanged);
            // 
            // txtFileToImport
            // 
            this.txtFileToImport.Location = new System.Drawing.Point(76, 15);
            this.txtFileToImport.Name = "txtFileToImport";
            this.txtFileToImport.Size = new System.Drawing.Size(275, 22);
            this.txtFileToImport.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "Job Source :";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(357, 16);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(57, 20);
            this.btnBrowse.TabIndex = 8;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // JobConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 573);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "JobConfig";
            this.Text = "Schedule";
            this.Load += new System.EventHandler(this.JobConfig_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgTriggerList)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.tabTrigger.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericRepeat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericInterval)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgTriggerList;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabControl tabTrigger;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnMinSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericRepeat;
        private System.Windows.Forms.NumericUpDown numericInterval;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnDaySave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDayDes;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnWeekSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox weekComBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnMonthSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox dayComBox;
        private System.Windows.Forms.TextBox txtMonthDes;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox allJobComBox;
        private System.Windows.Forms.TextBox txtFileToImport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblScheduleStatus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMinDes;
        private System.Windows.Forms.ComboBox hourComBoxDay;
        private System.Windows.Forms.ComboBox minComBoxDay;
        private System.Windows.Forms.TextBox txtWeekDes;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox minComBoxWeek;
        private System.Windows.Forms.ComboBox hourComBoxWeek;
        private System.Windows.Forms.ComboBox minComBoxMonth;
        private System.Windows.Forms.ComboBox hourComBoxMonth;
        private System.Windows.Forms.Button btnAction;

    }
}

