﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;
using Innolux.T2CIM.CommonUtl;

namespace Innolux.T2CIM.Module.WH
{
    public partial class frmFabTransferMtn : Form
    {
        CommonUI commonUI = new CommonUI();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        //WebReference.T2WS ws = new WebReference.T2WS();
        public frmFabTransferMtn()
        {
           // WebAccess.WebProxy = ws;
            InitializeComponent();
        }

        private void frmFabTransferMtn_Load(object sender, EventArgs e)
        {
            GetDefault();
        }
        private void GetDefault()
        {
            
            ResetControl();
            SetData();
        }
        private void ResetControl()
        {
            GetRoute();
            GetSection();
            GetCompany();
            GetPalletType();
            TransferDatePicker.Value = DateTime.Today;
            rbPCT.Checked = true;
            rbACT.Checked = true;
            rbMerge2.Checked = true;
            txtContent.Text = "";
            txtRequester.Text = "";
            txtPhonenumber.Text = "";
            txtPlateNumber.Text = "";
            txtCostCenter.Text = "";
            txtComments.Text = "";
            txtPalletCount.Text = "0";
        }
        private DataTable GetRoute()
        {
            string strSql = @"select t.fieldvalue from wh_fabtransfer_config t where t.fieldname='ROUTE' order by nvl(t.fieldtype,1) ";
            string jsonTxt = WebAccess.WebProxy.GetJsonStr(WebAccess.C_WH_DB, strSql);
            DataTable dtRoute = JsonConvert.DeserializeObject<DataTable>(jsonTxt.Trim());
            cbRoute.DisplayMember = "fieldvalue";
            cbRoute.ValueMember = "fieldvalue";
            cbRoute.DataSource = dtRoute;
            return dtRoute;
        }
        private DataTable GetSection()
        {
            string strSql = @"select t.fieldvalue from wh_fabtransfer_config t where t.fieldname='SECTION' order by nvl(t.fieldtype,1) ";
            string jsonTxt = WebAccess.WebProxy.GetJsonStr(WebAccess.C_WH_DB, strSql);
            DataTable dtSection = JsonConvert.DeserializeObject<DataTable>(jsonTxt.Trim());
            cbSection.DisplayMember = "fieldvalue";
            cbSection.ValueMember = "fieldvalue";
            cbSection.DataSource = dtSection;
            return dtSection;
        }
        private DataTable GetCompany()
        {
            string strSql = @"select t.fieldvalue from wh_fabtransfer_config t where t.fieldname='COMPANY' order by nvl(t.fieldtype,1) ";
            string jsonTxt = WebAccess.WebProxy.GetJsonStr(WebAccess.C_WH_DB, strSql);
            DataTable dtCompany = JsonConvert.DeserializeObject<DataTable>(jsonTxt.Trim());
            cbCompany.DisplayMember = "fieldvalue";
            cbCompany.ValueMember = "fieldvalue";
            cbCompany.DataSource = dtCompany;
            return dtCompany;
        }
        private DataTable GetPalletType()
        {
            string strSql = @"select t.fieldvalue from wh_fabtransfer_config t where t.fieldname='PALLET_TYPE' order by nvl(t.fieldtype,1) ";
            string jsonTxt = WebAccess.WebProxy.GetJsonStr(WebAccess.C_WH_DB, strSql);
            DataTable dtPallettype = JsonConvert.DeserializeObject<DataTable>(jsonTxt.Trim());
            cbPallettype.DisplayMember = "fieldvalue";
            cbPallettype.ValueMember = "fieldvalue";
            cbPallettype.DataSource = dtPallettype;
            return dtPallettype;
        }
        private void SetData()
        {
            ds = new DataSet();
            FabTransGridView.Columns.Clear();

            DataGridViewCheckBoxColumn chk = new DataGridViewCheckBoxColumn();
            chk.HeaderText = "Check";
            chk.Name = "IsSelected";
            chk.Width=50;
            FabTransGridView.Columns.Add(chk);
           
            
            commonUI.SetDataGridViewImageData(FabTransGridView, "Edit", 0);
            commonUI.SetDataGridViewImageData(FabTransGridView, "Delete", 1);
            dt = GetFabTransferHst();
            FabTransGridView.DataSource = dt;
           

        }
       
        private DataTable GetFabTransferHst()
        {
            string sqlFabTransferHst = @"select transferdate 廠移日, 
                                                pct_transfer 預計派車時段, 
                                                act_transfer 實際派車時段,
                                                merge_flag 併車0獨立1,
                                                dispatchcard_flag 開派車單, 
                                                route 路線,
                                                section 課, 
                                                content 內容,
                                                requester 需求者,
                                                phonenumber 電話,
                                                company 車行,
                                                platenumber 車號, 
                                                pallet_type 棧板規格,
                                                pallet_count 板數,
                                                comments 備註, 
                                                cost_center 成本中心,
                                                upd_time, upd_user,itemnum from wh_fabtransfer_hst 
                                        where item_flag=1 
                                        order by transferdate desc ";

            string jsonTxt = WebAccess.WebProxy.GetJsonStr(WebAccess.C_WH_DB, sqlFabTransferHst);
            DataTable dtHst = JsonConvert.DeserializeObject<DataTable>(jsonTxt.Trim());
            return dtHst;
        }

        private void FabTransDridView_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (FabTransGridView["Edit", e.RowIndex].ToolTipText != "Cancel" )
            {
                e.Cancel = true;
            }
        }

        private void FabTransDridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
            {
                // Prevent the user from clicking the table out of range.
            }
            else
            {

                if (FabTransGridView.Columns[e.ColumnIndex].Name == "IsSelected" && FabTransGridView.CurrentCell is DataGridViewCheckBoxCell)
                {
                    bool isChecked = (bool)FabTransGridView[e.ColumnIndex, e.RowIndex].EditedFormattedValue;
                    if (isChecked == false)
                    {
                        FabTransGridView.Rows[e.RowIndex].Cells[2].Value = "true";
                    }
                    else
                    {
                        FabTransGridView.Rows[e.RowIndex].Cells[2].Value = "false";
                    }
                    FabTransGridView.EndEdit();
                }


                string sTRANSFERDATE = FabTransGridView["廠移日", e.RowIndex].Value.ToString();
                string sPCT_TRANSFER = FabTransGridView["預計派車時段", e.RowIndex].Value.ToString();
                string sACT_TRANSFER = FabTransGridView["實際派車時段", e.RowIndex].Value.ToString();
                string sMERGE_FLAG = FabTransGridView["併車0獨立1", e.RowIndex].Value.ToString();
                string sDISPATCHCARD_FLAG = FabTransGridView["開派車單", e.RowIndex].Value.ToString();
                string sROUTE = FabTransGridView["路線", e.RowIndex].Value.ToString();

                string sSECTION = FabTransGridView["課", e.RowIndex].Value.ToString();
                string sCONTENT = FabTransGridView["內容", e.RowIndex].Value.ToString();
                string sREQUESTER = FabTransGridView["需求者", e.RowIndex].Value.ToString();
                string sPHONENUMBER = FabTransGridView["電話", e.RowIndex].Value.ToString();
                string sCOMPANY = FabTransGridView["車行", e.RowIndex].Value.ToString();

                string sPLATENUMBER = FabTransGridView["車號", e.RowIndex].Value.ToString();
                string sPALLET_TYPE = FabTransGridView["棧板規格", e.RowIndex].Value.ToString();
                string sPALLET_COUNT = FabTransGridView["板數", e.RowIndex].Value.ToString();
                string sCOMMENTS = FabTransGridView["備註", e.RowIndex].Value.ToString();
                string sCOST_CENTER = FabTransGridView["成本中心", e.RowIndex].Value.ToString();
                string sITEMNUM = FabTransGridView["ITEMNUM", e.RowIndex].Value.ToString();






                switch (FabTransGridView[e.ColumnIndex, e.RowIndex].ToolTipText)
                {
                    case "Edit":
                        btInsert.Enabled = false;
                        btUpdate.Enabled = true;
                        btCancelUpdate.Enabled = true;
                        if (sTRANSFERDATE.Trim() != null)
                        {
                           // ddlsCondition.SelectedIndex = 0;
                            TransferDatePicker.Value =DateTime.ParseExact(sTRANSFERDATE,"yyyyMMdd",System.Globalization.CultureInfo.InvariantCulture);
                        }
                        if (sPCT_TRANSFER.Trim() == "下午")
                        {
                            rbPCT2.Checked = true;
                        }
                        else
                        {
                            rbPCT.Checked = true;
                        }
                        if (sACT_TRANSFER.Trim() == "下午")
                        {
                            rbACT2.Checked = true;
                        }
                        else
                        {
                            rbACT.Checked = true;
                        }
                        if (sMERGE_FLAG.Trim() == "1")
                        {
                            rbMerge2.Checked = true;
                        }
                        else
                        {
                            rbMerge.Checked = true;
                        }
                        cbDispatch.SelectedIndex = 0;
                        cbDispatch.SelectedText = sDISPATCHCARD_FLAG;

                        cbRoute.SelectedIndex = 0;
                        cbRoute.SelectedText = sROUTE;

                        cbSection.SelectedIndex = 0;
                        cbSection.SelectedText = sSECTION;

                        txtContent.Text = sCONTENT;
                        txtRequester.Text = sREQUESTER;
                        txtPhonenumber.Text = sPHONENUMBER;

                        cbCompany.SelectedIndex = 0;
                        cbCompany.SelectedText = sCOMPANY;

                        txtPlateNumber.Text = sPLATENUMBER;

                        cbPallettype.SelectedIndex = 0;
                        cbPallettype.SelectedText = sPALLET_TYPE;

                        txtPalletCount.Text = sPALLET_COUNT;

                        txtComments.Text = sCOMMENTS;
                        txtCostCenter.Text = sCOST_CENTER;
                        lbitemnum.Text = sITEMNUM;
                        
                        break;
                   
                    case "Delete":
                        DialogResult result1 = MessageBox.Show("確定刪除 " + sTRANSFERDATE + " 資料?", "Confirm", MessageBoxButtons.YesNo);
                        if (result1 == DialogResult.Yes)
                        {
                            string delSQL = @"update wh_fabtransfer_hst 
                                                     set item_flag=0 ,
                                                         upd_user='{0}',
                                                         upd_time=sysdate               
                                            where itemnum=" + sITEMNUM;
                            delSQL = string.Format(delSQL, UserInfo.CurrentUser.EmployeeNo);
                            //UserInfo.CurrentUser.EmployeeNo
                            WebAccess.WebProxy.ExecuteNonQuery(WebAccess.C_WH_DB, delSQL);
                        }
                        GetDefault();
                        break;
                   
                }
            }
        }
     

      
        private void btInsert_Click(object sender, EventArgs e)
        {
            
            string iTransferDate = TransferDatePicker.Value.ToString("yyyyMMdd");
            if (iTransferDate == null)
            {
                MessageBox.Show("廠移日請選擇日期!");
                return;
            }
            string iPCT_Transfer = "";
            if (rbPCT.Checked)
            {
                iPCT_Transfer = "上午";
            }
            else
            {
                iPCT_Transfer = "下午";
            }
            string iACT_Transfer = "";
            if (rbACT.Checked)
            {
                iACT_Transfer = "上午";
            }
            else
            {
                iACT_Transfer = "下午";
            }
            string iMerge_flag = "";
            if (rbMerge.Checked)
            {
                iMerge_flag = "併";
            }
            else
            {
                iMerge_flag = "1";
            }

            string iDispatch = cbDispatch.Text;
            string iRoute = cbRoute.Text;
            string iSection = cbSection.Text;
            string iContent = txtContent.Text;
            string iRequester = txtRequester.Text;
            string iPhonenumber = txtPhonenumber.Text;
            string iCompany = cbCompany.Text;
            string iPlateNumber = txtPlateNumber.Text;
            string iPallettype = cbPallettype.Text;
            string iPalletCount = txtPalletCount.Text;
            int n;
            if (!int.TryParse(iPalletCount, out n))
            {
                MessageBox.Show("棧板內容-板數請填數字!");
                return;
            }
            string iComments = txtComments.Text;
            string iCostCenter = txtCostCenter.Text;
            DialogResult result1 = MessageBox.Show("確定新增 " + iTransferDate + " 資料?", "Confirm", MessageBoxButtons.YesNo);
            if (result1 == DialogResult.Yes)
            {
                string insertSQL = @"
                            insert into wh_fabtransfer_hst
                                    (transferdate, pct_transfer, act_transfer, merge_flag, dispatchcard_flag, route, section, 
                                    content, requester, phonenumber, company, platenumber, pallet_type, pallet_count, 
                                    comments,cost_center, upd_time, upd_user, itemnum, item_flag)
                            values
                                    ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}',
                                     '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', {13},
                                     '{14}','{15}', sysdate, '{16}', (select nvl(max(aa.itemnum),0)+1 from wh_fabtransfer_hst aa), 1)";

                insertSQL = string.Format(insertSQL, iTransferDate, iPCT_Transfer, iACT_Transfer, iMerge_flag, iDispatch, iRoute, iSection,
                                         iContent, iRequester, iPhonenumber, iCompany, iPlateNumber, iPallettype, iPalletCount,
                                         iComments,iCostCenter, UserInfo.CurrentUser.EmployeeNo);
                WebAccess.WebProxy.ExecuteNonQuery(WebAccess.C_WH_DB, insertSQL);

                MessageBox.Show(iTransferDate + " 資料新增成功!");
                GetDefault();
            }
            
        }

        private void btCancelUpdate_Click(object sender, EventArgs e)
        {
            btInsert.Enabled = true;
            btUpdate.Enabled = false;
            btCancelUpdate.Enabled = false;

            GetDefault();
        }

        private void btUpdate_Click(object sender, EventArgs e)
        {
            string uTransferDate = TransferDatePicker.Value.ToString("yyyyMMdd");
            if (uTransferDate == null)
            {
                MessageBox.Show("廠移日請選擇日期!");
                return;
            }
            string uPCT_Transfer = "";
            if (rbPCT.Checked)
            {
                uPCT_Transfer = "上午";
            }
            else
            {
                uPCT_Transfer = "下午";
            }
            string uACT_Transfer = "";
            if (rbACT.Checked)
            {
                uACT_Transfer = "上午";
            }
            else
            {
                uACT_Transfer = "下午";
            }
            string uMerge_flag = "";
            if (rbMerge.Checked)
            {
                uMerge_flag = "併";
            }
            else
            {
                uMerge_flag = "1";
            }

            string uDispatch = cbDispatch.Text;
            string uRoute = cbRoute.Text;
            string uSection = cbSection.Text;
            string uContent = txtContent.Text;
            string uRequester = txtRequester.Text;
            string uPhonenumber = txtPhonenumber.Text;
            
            string uCompany = cbCompany.Text;
            string uPlateNumber = txtPlateNumber.Text;
            string uPallettype = cbPallettype.Text;
            string uPalletCount = txtPalletCount.Text;
            int n;
            if (!int.TryParse(uPalletCount, out n))
            {
                MessageBox.Show("棧板內容-板數請填數字!");
                return;
            }
            string uComments = txtComments.Text;
            string uCostCenter = txtCostCenter.Text;
            string uItemnum = lbitemnum.Text;
            DialogResult result1 = MessageBox.Show("確定修改 " + uTransferDate + " 資料?", "Confirm", MessageBoxButtons.YesNo);
            if (result1 == DialogResult.Yes)
            {
                string updSQL = @"update wh_fabtransfer_hst 
                                   set transferdate = '{0}',pct_transfer = '{1}',act_transfer = '{2}',merge_flag = '{3}',
                                       dispatchcard_flag = '{4}',route = '{5}',section = '{6}',content = '{7}',
                                       requester = '{8}',phonenumber = '{9}',company = '{10}',platenumber = '{11}',
                                       pallet_type = '{12}',pallet_count = {13},comments = '{14}',cost_center = '{15}',
                                       upd_time = sysdate,upd_user = '{16}' 
                                where itemnum=" + uItemnum;
                updSQL = string.Format(updSQL, uTransferDate, uPCT_Transfer, uACT_Transfer, uMerge_flag, 
                                                uDispatch, uRoute, uSection,uContent, 
                                    uRequester, uPhonenumber, uCompany, uPlateNumber,
                                    uPallettype, uPalletCount, uComments,uCostCenter, UserInfo.CurrentUser.EmployeeNo);
                WebAccess.WebProxy.ExecuteNonQuery(WebAccess.C_WH_DB, updSQL);
            }
            btInsert.Enabled = true;
            btUpdate.Enabled = false;
            btCancelUpdate.Enabled = false;

            GetDefault();
        }

        private void exportBtn_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            DataTable dtexcel = GetDataTableFromDGV(FabTransGridView);// GetFabTransferHst();
            try
            {
                commonUI.Export2Xls(dtexcel, "data");
            }
            finally
            {
                Cursor.Current = Cursors.Default;
                dtexcel.Clear();
                dtexcel.Dispose();
            }




        }
        private DataTable GetDataTableFromDGV(DataGridView dgv)
        {
            string ExportList = "";
            DataTable dt = ((DataTable)dgv.DataSource).Clone();
            DataTable dt_Temp = ((DataTable)dgv.DataSource).Copy();
            foreach (DataGridViewRow row in dgv.Rows)
            {
                bool checkexport=(bool)row.Cells[2].FormattedValue;
                string dataItem=row.Cells[21].Value.ToString();
                if (checkexport)
                {
                    ExportList = ExportList + dataItem+",";
                }
               // dt.ImportRow((DataRow)row.DataGridView);
            }

            if (ExportList.Length > 0)
            {
                ExportList = ExportList.Substring(0, ExportList.Length - 1);



                foreach (DataRow row in dt_Temp.Select(" ITEMNUM IN(" + ExportList + ")"))
                {
                    dt.ImportRow(row);
                }
            }
            else
            {
                dt = dt_Temp;
            }
            return dt;
        }
    
    }
}
