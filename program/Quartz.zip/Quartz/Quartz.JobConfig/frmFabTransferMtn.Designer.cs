﻿namespace Innolux.T2CIM.Module.WH
{
    partial class frmFabTransferMtn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.FabTransGridView = new System.Windows.Forms.DataGridView();
            this.gbDataView = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exportBtn = new System.Windows.Forms.Button();
            this.gbCostCenter = new System.Windows.Forms.GroupBox();
            this.txtCostCenter = new System.Windows.Forms.TextBox();
            this.lbitemnum = new System.Windows.Forms.Label();
            this.gbComments = new System.Windows.Forms.GroupBox();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbPallettype = new System.Windows.Forms.ComboBox();
            this.txtPalletCount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.gbContainer = new System.Windows.Forms.GroupBox();
            this.cbCompany = new System.Windows.Forms.ComboBox();
            this.txtPlateNumber = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.gbContent = new System.Windows.Forms.GroupBox();
            this.txtPhonenumber = new System.Windows.Forms.TextBox();
            this.txtRequester = new System.Windows.Forms.TextBox();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbSection = new System.Windows.Forms.GroupBox();
            this.cbSection = new System.Windows.Forms.ComboBox();
            this.gbRoute = new System.Windows.Forms.GroupBox();
            this.cbRoute = new System.Windows.Forms.ComboBox();
            this.btCancelUpdate = new System.Windows.Forms.Button();
            this.btUpdate = new System.Windows.Forms.Button();
            this.btInsert = new System.Windows.Forms.Button();
            this.gbDispatch = new System.Windows.Forms.GroupBox();
            this.cbDispatch = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbMerge = new System.Windows.Forms.RadioButton();
            this.rbMerge2 = new System.Windows.Forms.RadioButton();
            this.gbACT = new System.Windows.Forms.GroupBox();
            this.rbACT = new System.Windows.Forms.RadioButton();
            this.rbACT2 = new System.Windows.Forms.RadioButton();
            this.gbPCT = new System.Windows.Forms.GroupBox();
            this.rbPCT = new System.Windows.Forms.RadioButton();
            this.rbPCT2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TransferDatePicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.FabTransGridView)).BeginInit();
            this.gbDataView.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gbCostCenter.SuspendLayout();
            this.gbComments.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbContainer.SuspendLayout();
            this.gbContent.SuspendLayout();
            this.gbSection.SuspendLayout();
            this.gbRoute.SuspendLayout();
            this.gbDispatch.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.gbACT.SuspendLayout();
            this.gbPCT.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // FabTransGridView
            // 
            this.FabTransGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.FabTransGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.FabTransGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.FabTransGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.FabTransGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FabTransGridView.Location = new System.Drawing.Point(10, 25);
            this.FabTransGridView.MultiSelect = false;
            this.FabTransGridView.Name = "FabTransGridView";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.FabTransGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.FabTransGridView.RowTemplate.Height = 24;
            this.FabTransGridView.Size = new System.Drawing.Size(752, 267);
            this.FabTransGridView.TabIndex = 0;
            this.FabTransGridView.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.FabTransDridView_CellBeginEdit);
            this.FabTransGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FabTransDridView_CellClick);
            
            
            // 
            // gbDataView
            // 
            this.gbDataView.Controls.Add(this.FabTransGridView);
            this.gbDataView.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbDataView.Location = new System.Drawing.Point(10, 10);
            this.gbDataView.Name = "gbDataView";
            this.gbDataView.Padding = new System.Windows.Forms.Padding(10);
            this.gbDataView.Size = new System.Drawing.Size(772, 302);
            this.gbDataView.TabIndex = 1;
            this.gbDataView.TabStop = false;
            this.gbDataView.Text = "廠移資訊";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.exportBtn);
            this.panel1.Controls.Add(this.gbCostCenter);
            this.panel1.Controls.Add(this.lbitemnum);
            this.panel1.Controls.Add(this.gbComments);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.gbContainer);
            this.panel1.Controls.Add(this.gbContent);
            this.panel1.Controls.Add(this.gbSection);
            this.panel1.Controls.Add(this.gbRoute);
            this.panel1.Controls.Add(this.btCancelUpdate);
            this.panel1.Controls.Add(this.btUpdate);
            this.panel1.Controls.Add(this.btInsert);
            this.panel1.Controls.Add(this.gbDispatch);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.gbACT);
            this.panel1.Controls.Add(this.gbPCT);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(10, 312);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(772, 244);
            this.panel1.TabIndex = 2;
            // 
            // exportBtn
            // 
            this.exportBtn.Location = new System.Drawing.Point(697, 181);
            this.exportBtn.Name = "exportBtn";
            this.exportBtn.Size = new System.Drawing.Size(75, 23);
            this.exportBtn.TabIndex = 39;
            this.exportBtn.Text = "匯出";
            this.exportBtn.UseVisualStyleBackColor = true;
            this.exportBtn.Click += new System.EventHandler(this.exportBtn_Click);
            // 
            // gbCostCenter
            // 
            this.gbCostCenter.Controls.Add(this.txtCostCenter);
            this.gbCostCenter.Location = new System.Drawing.Point(621, 88);
            this.gbCostCenter.Name = "gbCostCenter";
            this.gbCostCenter.Size = new System.Drawing.Size(150, 57);
            this.gbCostCenter.TabIndex = 38;
            this.gbCostCenter.TabStop = false;
            this.gbCostCenter.Text = "成本中心";
            // 
            // txtCostCenter
            // 
            this.txtCostCenter.Location = new System.Drawing.Point(12, 21);
            this.txtCostCenter.Name = "txtCostCenter";
            this.txtCostCenter.Size = new System.Drawing.Size(128, 22);
            this.txtCostCenter.TabIndex = 6;
            // 
            // lbitemnum
            // 
            this.lbitemnum.AutoSize = true;
            this.lbitemnum.Location = new System.Drawing.Point(616, 218);
            this.lbitemnum.Name = "lbitemnum";
            this.lbitemnum.Size = new System.Drawing.Size(11, 12);
            this.lbitemnum.TabIndex = 37;
            this.lbitemnum.Text = "0";
            this.lbitemnum.Visible = false;
            // 
            // gbComments
            // 
            this.gbComments.Controls.Add(this.txtComments);
            this.gbComments.Location = new System.Drawing.Point(622, 3);
            this.gbComments.Name = "gbComments";
            this.gbComments.Padding = new System.Windows.Forms.Padding(10);
            this.gbComments.Size = new System.Drawing.Size(149, 84);
            this.gbComments.TabIndex = 36;
            this.gbComments.TabStop = false;
            this.gbComments.Text = "備註";
            // 
            // txtComments
            // 
            this.txtComments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtComments.Location = new System.Drawing.Point(10, 25);
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(129, 49);
            this.txtComments.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbPallettype);
            this.groupBox2.Controls.Add(this.txtPalletCount);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(416, 121);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 117);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "棧板內容";
            // 
            // cbPallettype
            // 
            this.cbPallettype.FormattingEnabled = true;
            this.cbPallettype.Items.AddRange(new object[] {
            "",
            "V",
            "X"});
            this.cbPallettype.Location = new System.Drawing.Point(95, 30);
            this.cbPallettype.Name = "cbPallettype";
            this.cbPallettype.Size = new System.Drawing.Size(69, 20);
            this.cbPallettype.TabIndex = 1;
            // 
            // txtPalletCount
            // 
            this.txtPalletCount.Location = new System.Drawing.Point(95, 70);
            this.txtPalletCount.Name = "txtPalletCount";
            this.txtPalletCount.Size = new System.Drawing.Size(69, 22);
            this.txtPalletCount.TabIndex = 3;
            this.txtPalletCount.Text = "0";
            this.txtPalletCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "板數：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "棧板規格：";
            // 
            // gbContainer
            // 
            this.gbContainer.Controls.Add(this.cbCompany);
            this.gbContainer.Controls.Add(this.txtPlateNumber);
            this.gbContainer.Controls.Add(this.label4);
            this.gbContainer.Controls.Add(this.label5);
            this.gbContainer.Location = new System.Drawing.Point(416, 3);
            this.gbContainer.Name = "gbContainer";
            this.gbContainer.Size = new System.Drawing.Size(200, 117);
            this.gbContainer.TabIndex = 34;
            this.gbContainer.TabStop = false;
            this.gbContainer.Text = "貨櫃內容";
            // 
            // cbCompany
            // 
            this.cbCompany.FormattingEnabled = true;
            this.cbCompany.Items.AddRange(new object[] {
            "",
            "V",
            "X"});
            this.cbCompany.Location = new System.Drawing.Point(98, 27);
            this.cbCompany.Name = "cbCompany";
            this.cbCompany.Size = new System.Drawing.Size(69, 20);
            this.cbCompany.TabIndex = 1;
            // 
            // txtPlateNumber
            // 
            this.txtPlateNumber.Location = new System.Drawing.Point(67, 69);
            this.txtPlateNumber.Name = "txtPlateNumber";
            this.txtPlateNumber.Size = new System.Drawing.Size(100, 22);
            this.txtPlateNumber.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = " 車號：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "車行：";
            // 
            // gbContent
            // 
            this.gbContent.Controls.Add(this.txtPhonenumber);
            this.gbContent.Controls.Add(this.txtRequester);
            this.gbContent.Controls.Add(this.txtContent);
            this.gbContent.Controls.Add(this.label3);
            this.gbContent.Controls.Add(this.label2);
            this.gbContent.Controls.Add(this.label1);
            this.gbContent.Location = new System.Drawing.Point(199, 99);
            this.gbContent.Name = "gbContent";
            this.gbContent.Size = new System.Drawing.Size(200, 143);
            this.gbContent.TabIndex = 33;
            this.gbContent.TabStop = false;
            this.gbContent.Text = "內容";
            // 
            // txtPhonenumber
            // 
            this.txtPhonenumber.Location = new System.Drawing.Point(64, 111);
            this.txtPhonenumber.Name = "txtPhonenumber";
            this.txtPhonenumber.Size = new System.Drawing.Size(100, 22);
            this.txtPhonenumber.TabIndex = 5;
            // 
            // txtRequester
            // 
            this.txtRequester.Location = new System.Drawing.Point(64, 71);
            this.txtRequester.Name = "txtRequester";
            this.txtRequester.Size = new System.Drawing.Size(100, 22);
            this.txtRequester.TabIndex = 4;
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(64, 30);
            this.txtContent.Name = "txtContent";
            this.txtContent.Size = new System.Drawing.Size(100, 22);
            this.txtContent.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "電話：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "需求者：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "內容：";
            // 
            // gbSection
            // 
            this.gbSection.Controls.Add(this.cbSection);
            this.gbSection.Location = new System.Drawing.Point(199, 52);
            this.gbSection.Name = "gbSection";
            this.gbSection.Size = new System.Drawing.Size(200, 46);
            this.gbSection.TabIndex = 31;
            this.gbSection.TabStop = false;
            this.gbSection.Text = "課";
            // 
            // cbSection
            // 
            this.cbSection.FormattingEnabled = true;
            this.cbSection.Items.AddRange(new object[] {
            "",
            "V",
            "X"});
            this.cbSection.Location = new System.Drawing.Point(20, 16);
            this.cbSection.Name = "cbSection";
            this.cbSection.Size = new System.Drawing.Size(153, 20);
            this.cbSection.TabIndex = 0;
            // 
            // gbRoute
            // 
            this.gbRoute.Controls.Add(this.cbRoute);
            this.gbRoute.Location = new System.Drawing.Point(199, 3);
            this.gbRoute.Name = "gbRoute";
            this.gbRoute.Size = new System.Drawing.Size(200, 46);
            this.gbRoute.TabIndex = 29;
            this.gbRoute.TabStop = false;
            this.gbRoute.Text = "路線";
            // 
            // cbRoute
            // 
            this.cbRoute.FormattingEnabled = true;
            this.cbRoute.Items.AddRange(new object[] {
            "",
            "V",
            "X"});
            this.cbRoute.Location = new System.Drawing.Point(20, 17);
            this.cbRoute.Name = "cbRoute";
            this.cbRoute.Size = new System.Drawing.Size(153, 20);
            this.cbRoute.TabIndex = 0;
            // 
            // btCancelUpdate
            // 
            this.btCancelUpdate.Enabled = false;
            this.btCancelUpdate.Location = new System.Drawing.Point(621, 181);
            this.btCancelUpdate.Name = "btCancelUpdate";
            this.btCancelUpdate.Size = new System.Drawing.Size(75, 23);
            this.btCancelUpdate.TabIndex = 32;
            this.btCancelUpdate.Text = "取消修改";
            this.btCancelUpdate.UseVisualStyleBackColor = true;
            this.btCancelUpdate.Click += new System.EventHandler(this.btCancelUpdate_Click);
            // 
            // btUpdate
            // 
            this.btUpdate.Enabled = false;
            this.btUpdate.Location = new System.Drawing.Point(621, 151);
            this.btUpdate.Name = "btUpdate";
            this.btUpdate.Size = new System.Drawing.Size(75, 23);
            this.btUpdate.TabIndex = 30;
            this.btUpdate.Text = "修改";
            this.btUpdate.UseVisualStyleBackColor = true;
            this.btUpdate.Click += new System.EventHandler(this.btUpdate_Click);
            // 
            // btInsert
            // 
            this.btInsert.Location = new System.Drawing.Point(697, 151);
            this.btInsert.Name = "btInsert";
            this.btInsert.Size = new System.Drawing.Size(75, 23);
            this.btInsert.TabIndex = 28;
            this.btInsert.Text = "新增";
            this.btInsert.UseVisualStyleBackColor = true;
            this.btInsert.Click += new System.EventHandler(this.btInsert_Click);
            // 
            // gbDispatch
            // 
            this.gbDispatch.Controls.Add(this.cbDispatch);
            this.gbDispatch.Location = new System.Drawing.Point(1, 196);
            this.gbDispatch.Name = "gbDispatch";
            this.gbDispatch.Size = new System.Drawing.Size(186, 46);
            this.gbDispatch.TabIndex = 27;
            this.gbDispatch.TabStop = false;
            this.gbDispatch.Text = "開派車單";
            // 
            // cbDispatch
            // 
            this.cbDispatch.FormattingEnabled = true;
            this.cbDispatch.Items.AddRange(new object[] {
            "",
            "V",
            "X"});
            this.cbDispatch.Location = new System.Drawing.Point(20, 20);
            this.cbDispatch.Name = "cbDispatch";
            this.cbDispatch.Size = new System.Drawing.Size(129, 20);
            this.cbDispatch.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbMerge);
            this.groupBox3.Controls.Add(this.rbMerge2);
            this.groupBox3.Location = new System.Drawing.Point(1, 148);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(186, 46);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "併車or獨立";
            // 
            // rbMerge
            // 
            this.rbMerge.AutoSize = true;
            this.rbMerge.Location = new System.Drawing.Point(20, 21);
            this.rbMerge.Name = "rbMerge";
            this.rbMerge.Size = new System.Drawing.Size(47, 16);
            this.rbMerge.TabIndex = 6;
            this.rbMerge.Text = "併車";
            this.rbMerge.UseVisualStyleBackColor = true;
            // 
            // rbMerge2
            // 
            this.rbMerge2.AutoSize = true;
            this.rbMerge2.Checked = true;
            this.rbMerge2.Location = new System.Drawing.Point(102, 21);
            this.rbMerge2.Name = "rbMerge2";
            this.rbMerge2.Size = new System.Drawing.Size(47, 16);
            this.rbMerge2.TabIndex = 7;
            this.rbMerge2.TabStop = true;
            this.rbMerge2.Text = "獨立";
            this.rbMerge2.UseVisualStyleBackColor = true;
            // 
            // gbACT
            // 
            this.gbACT.Controls.Add(this.rbACT);
            this.gbACT.Controls.Add(this.rbACT2);
            this.gbACT.Location = new System.Drawing.Point(1, 101);
            this.gbACT.Name = "gbACT";
            this.gbACT.Size = new System.Drawing.Size(186, 46);
            this.gbACT.TabIndex = 25;
            this.gbACT.TabStop = false;
            this.gbACT.Text = "實際派車時段";
            // 
            // rbACT
            // 
            this.rbACT.AutoSize = true;
            this.rbACT.Checked = true;
            this.rbACT.Location = new System.Drawing.Point(20, 21);
            this.rbACT.Name = "rbACT";
            this.rbACT.Size = new System.Drawing.Size(47, 16);
            this.rbACT.TabIndex = 6;
            this.rbACT.TabStop = true;
            this.rbACT.Text = "上午";
            this.rbACT.UseVisualStyleBackColor = true;
            // 
            // rbACT2
            // 
            this.rbACT2.AutoSize = true;
            this.rbACT2.Location = new System.Drawing.Point(102, 21);
            this.rbACT2.Name = "rbACT2";
            this.rbACT2.Size = new System.Drawing.Size(47, 16);
            this.rbACT2.TabIndex = 7;
            this.rbACT2.Text = "下午";
            this.rbACT2.UseVisualStyleBackColor = true;
            // 
            // gbPCT
            // 
            this.gbPCT.Controls.Add(this.rbPCT);
            this.gbPCT.Controls.Add(this.rbPCT2);
            this.gbPCT.Location = new System.Drawing.Point(1, 53);
            this.gbPCT.Name = "gbPCT";
            this.gbPCT.Size = new System.Drawing.Size(186, 46);
            this.gbPCT.TabIndex = 24;
            this.gbPCT.TabStop = false;
            this.gbPCT.Text = "預計派車時段";
            // 
            // rbPCT
            // 
            this.rbPCT.AutoSize = true;
            this.rbPCT.Checked = true;
            this.rbPCT.Location = new System.Drawing.Point(20, 21);
            this.rbPCT.Name = "rbPCT";
            this.rbPCT.Size = new System.Drawing.Size(47, 16);
            this.rbPCT.TabIndex = 6;
            this.rbPCT.TabStop = true;
            this.rbPCT.Text = "上午";
            this.rbPCT.UseVisualStyleBackColor = true;
            // 
            // rbPCT2
            // 
            this.rbPCT2.AutoSize = true;
            this.rbPCT2.Location = new System.Drawing.Point(102, 21);
            this.rbPCT2.Name = "rbPCT2";
            this.rbPCT2.Size = new System.Drawing.Size(47, 16);
            this.rbPCT2.TabIndex = 7;
            this.rbPCT2.Text = "下午";
            this.rbPCT2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TransferDatePicker);
            this.groupBox1.Location = new System.Drawing.Point(1, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(186, 49);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "廠移日";
            // 
            // TransferDatePicker
            // 
            this.TransferDatePicker.CustomFormat = "yyyyMMdd";
            this.TransferDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TransferDatePicker.Location = new System.Drawing.Point(18, 18);
            this.TransferDatePicker.Name = "TransferDatePicker";
            this.TransferDatePicker.Size = new System.Drawing.Size(131, 22);
            this.TransferDatePicker.TabIndex = 2;
            this.TransferDatePicker.Value = new System.DateTime(2016, 3, 9, 0, 0, 0, 0);
            // 
            // frmFabTransferMtn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbDataView);
            this.Name = "frmFabTransferMtn";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Load += new System.EventHandler(this.frmFabTransferMtn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FabTransGridView)).EndInit();
            this.gbDataView.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gbCostCenter.ResumeLayout(false);
            this.gbCostCenter.PerformLayout();
            this.gbComments.ResumeLayout(false);
            this.gbComments.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbContainer.ResumeLayout(false);
            this.gbContainer.PerformLayout();
            this.gbContent.ResumeLayout(false);
            this.gbContent.PerformLayout();
            this.gbSection.ResumeLayout(false);
            this.gbRoute.ResumeLayout(false);
            this.gbDispatch.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.gbACT.ResumeLayout(false);
            this.gbACT.PerformLayout();
            this.gbPCT.ResumeLayout(false);
            this.gbPCT.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView FabTransGridView;
        private System.Windows.Forms.GroupBox gbDataView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbitemnum;
        private System.Windows.Forms.GroupBox gbComments;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbPallettype;
        private System.Windows.Forms.TextBox txtPalletCount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox gbContainer;
        private System.Windows.Forms.ComboBox cbCompany;
        private System.Windows.Forms.TextBox txtPlateNumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox gbContent;
        private System.Windows.Forms.TextBox txtPhonenumber;
        private System.Windows.Forms.TextBox txtRequester;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbSection;
        private System.Windows.Forms.ComboBox cbSection;
        private System.Windows.Forms.GroupBox gbRoute;
        private System.Windows.Forms.ComboBox cbRoute;
        private System.Windows.Forms.Button btCancelUpdate;
        private System.Windows.Forms.Button btUpdate;
        private System.Windows.Forms.Button btInsert;
        private System.Windows.Forms.GroupBox gbDispatch;
        private System.Windows.Forms.ComboBox cbDispatch;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbMerge;
        private System.Windows.Forms.RadioButton rbMerge2;
        private System.Windows.Forms.GroupBox gbACT;
        private System.Windows.Forms.RadioButton rbACT;
        private System.Windows.Forms.RadioButton rbACT2;
        private System.Windows.Forms.GroupBox gbPCT;
        private System.Windows.Forms.RadioButton rbPCT;
        private System.Windows.Forms.RadioButton rbPCT2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker TransferDatePicker;
        private System.Windows.Forms.GroupBox gbCostCenter;
        private System.Windows.Forms.TextBox txtCostCenter;
        private System.Windows.Forms.Button exportBtn;

    }
}