﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using Quartz.CustomJob.Job.Scheduler;

namespace Quartz.CustomJob.Base
{
    public abstract class JobBsae : IJob
    {
        #region Mail members
        private bool needMail;
        /// <summary>
        /// get or set if need send mail
        /// </summary>
        public bool NeedSendMail
        {
            get { return this.needMail; }
            set { this.needMail = value; }
        }
        private string mailServerIP;
        /// <summary>
        /// get or set the mail server IP
        /// </summary>
        public string MailServerIP
        {
            get { return this.mailServerIP; }
            set { this.mailServerIP = value; }
        }
        private string backupMailServerIP;
        /// <summary>
        /// get or set backup mail server IP
        /// </summary>
        public string BackupMailServerIP
        {
            get { return this.backupMailServerIP; }
            set { this.backupMailServerIP = value; }
        }
        #endregion

        #region FTP members
        private bool needFTP;
        /// <summary>
        /// get or set is need FTP
        /// </summary>
        public bool NeedFTP
        {
            get { return this.needFTP; }
            set { this.needFTP = value; }
        }
        private string ftpServerIP;
        /// <summary>
        /// get or set FTP server IP
        /// </summary>
        public string FTPServerIP
        {
            get { return this.ftpServerIP; }
            set { this.ftpServerIP = value; }
        }
        private string ftpUserId;
        /// <summary>
        /// get or set login ftp user ID
        /// </summary>
        public string FTPUserId
        {
            get { return this.ftpUserId; }
            set { this.ftpUserId = value; }
        }
        private string ftpPwd;
        /// <summary>
        /// get or set login FTP password
        /// </summary>
        public string FTPPwd
        {
            get { return this.ftpPwd; }
            set { this.ftpPwd = value; }
        }
        private string ftpDir;
        /// <summary>
        /// set or get the FTP directory
        /// </summary>
        public string FTPDir
        {
            get { return this.ftpDir; }
            set { this.ftpDir = value; }
        }
        #endregion

        private string resultFolder = "TempFiles/";    // Default folder
        /// <summary>
        /// default save the excel file folder
        /// </summary>
        public string ResultFolder
        {
            get { return this.resultFolder; }
            set { this.resultFolder = value; }
        }

        public string HostIP
        {
            get
            {
                System.Net.IPHostEntry hostInfo = Dns.GetHostEntry(System.Net.Dns.GetHostName());
                return hostInfo.AddressList[1].ToString();
            }
        }

        public string Name { get { return this.GetType().Name; } }

        private Guid identityID = Guid.NewGuid();
        /// <summary>
        /// Get export file full name, include path
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        /// 
        protected virtual string GetFileFullName(string fileName)
        {
            return AppDomain.CurrentDomain.BaseDirectory + this.ResultFolder.Replace('/', '\\') + fileName;
        }

        #region IJob Members
        /// <summary>
        /// execute the schedule job
        /// </summary>
        /// <param name="context"></param>
        public virtual void Execute(IJobExecutionContext context)
        {
            ReportLogProvider logProvider = new ReportLogProvider(identityID);

            try
            {
                logProvider.WriteLog(this.Name, string.Format("Start run ({0}) ......", this.Name), "Run", "Notify", "1", this.HostIP);

                this.RunSchedule(context);

                logProvider.WriteLog(this.Name, string.Format("End run ({0}) ......", this.Name), "Run", "Notify", "1", this.HostIP);
            }
            catch (Exception ex)
            {
                logProvider.WriteLog(this.Name, "Run Schedule error:" + ex.Message, "Export", "Error", "1", this.HostIP);
            }
        }

        public virtual void RunSchedule(IJobExecutionContext context)
        {
        }

        #endregion
    }
}
