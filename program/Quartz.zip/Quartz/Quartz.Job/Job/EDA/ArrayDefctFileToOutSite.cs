﻿using System;
using System.Linq;
using System.Text;
using System.Data;
using System.Net;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Collections;
using System.Collections.Generic;
using Innolux.Portal.Common.Mapp;
using Innolux.Portal.Common.MailClass;
using Innolux.Portal.Common.FileClass;
using Common.Logging;
using Newtonsoft.Json;
using Quartz.CustomJob.Base;
using Quartz.CustomJob.Job.Scheduler;

namespace Quartz.CustomJob.Job.EDA
{
    class T1ArrayDefctFileToOutSite : JobBsae
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(T1ArrayDefctFileToOutSite));
        private WebReference.AOEWS ws = new WebReference.AOEWS();

        public override void RunSchedule(IJobExecutionContext context)
        {
            ReportLogProvider logProvider = new ReportLogProvider(Guid.NewGuid());

            try
            {
                string shiftDate = DateTime.Now.ToString("yyyyMMdd");

                string shop = "T1ARRAY";
                if (!CheckScheduleRptLog(shiftDate))//確認有無執行過
                {
                    try
                    {
                        //logProvider.WriteLog(this.Name, string.Format("Start run ({0}) ......", this.Name), "Run", "Notify", "1", this.HostIP);

                        ArrayDefectToMQFileAndPushToFtp arrayDefectToMQFileAndPushToFtp = new ArrayDefectToMQFileAndPushToFtp(shop, "TT09", "TFTR2", shiftDate);
                        arrayDefectToMQFileAndPushToFtp.Execute();

                        logProvider.WriteLog(this.Name, arrayDefectToMQFileAndPushToFtp.MappMsg, "Run", "Notify", "1", this.HostIP);

                        //logger.Info(context.JobDetail.JobType.ToString() + " run finished... ");
                    }
                    catch (Exception ex)
                    {
                        logProvider.WriteLog(this.Name, "T1Array To TT09 Run Schedule error:" + ex.Message, "Export", "Error", "1", this.HostIP);
                    }

                    InsScheduleRptLog(shiftDate);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool CheckScheduleRptLog(string shiftDate)
        {
            bool bResult = false;
            string sqlStr = @"
                select count(*)  from SCHEDULE_RPT_LOG 
                    where REPORT_DATE = '{0}' 
                    and REPORT_TYPE = 'Daily'
                    and REPORT_NAME = 'T1ArrayDefctFileToOutSite'";

            sqlStr = string.Format(sqlStr, shiftDate);

            DataTable dt = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("EDA DB", sqlStr));
            if (dt.Rows.Count > 0)
            {
                bResult = (Convert.ToInt32(dt.Rows[0][0]) > 0) ? true : false;
            }

            return bResult;
        }

        public void InsScheduleRptLog(string shiftDate)
        {
            string sqlStr = @"insert into schedule_rpt_log
                                  (report_name, report_type, report_date, log_date, serverip)
                                values
                                  ('{0}', 'Daily', '{1}', sysdate, '{2}')";

            sqlStr = string.Format(sqlStr, "T1ArrayDefctFileToOutSite", shiftDate, this.HostIP);
            ws.ExecuteNonQuery("EDA DB", sqlStr);
        }
    }

    public class ArrayDefectToMQFileAndPushToFtp
    {
        //constructor field
        private string sourceShop;
        private string sourceFab;
        private string destShop;
        private string destStep;
        private string shiftDate;
        private string shiftDateTime;
        private string shiftDateTimeBefore;
        //相關Defect & Eq 資料
        private DataTable TotalLaserDefectInfo;
        private DataTable TotalLaserEqInfo;
        private DataTable TotalTestEqInfo;
        private DataTable TotalCVDEqInfo;
        private DataTable TotalGlassInfo;
        private DataTable TotalChipInfo;
        //Eq data
        private string cvdEqId;
        private string cvdEqStartTime;
        private string cvdEqEndTime;
        private string cvdOperator;
        private string testEqId;
        private string testEqStartTime;
        private string testEqEndTime;
        private string laserEqId;
        private string laserEqStartTime;
        private string laserEqEndTime;
        private string laserOperator;
        //index list
        private ArrayList indexArray = new ArrayList();

        private string defectAndIndexFileDirectory;
        private string sourceShopDescStepDirectory;
        private string zipFileName;
        private string destShopArea;
        private string destShopDesc;
        private string mappMsg;

        private WebReference.AOEWS ws;

        public ArrayDefectToMQFileAndPushToFtp(string _sourceShop, string _destShop, string _destStep, string _shiftDate)
        {
            this.sourceShop = _sourceShop.Substring(0, 2);
            this.sourceFab = _sourceShop.Substring(2);
            this.destShop = _destShop;
            this.destStep = _destStep;
            this.shiftDate = _shiftDate;
            this.shiftDateTime = _shiftDate + "060000";
            //前一天
            this.shiftDateTimeBefore = Convert.ToDateTime(shiftDate.Substring(0, 4) + "/" + shiftDate.Substring(4, 2) + "/" + shiftDate.Substring(6, 2)).AddDays(-1).ToString("yyyyMMdd") + "060000";

            this.ws = new WebReference.AOEWS();

            try
            {
                GetDestShopArea();//取得目的端的shop對照
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //T1_TFTR2_20171024121519
            this.sourceShopDescStepDirectory = string.Format(@"{2}_{3}_{4}", _sourceShop, shiftDate, sourceShop, destStep, DateTime.Now.ToString("yyyyMMddHHmmss"));
            //EDA\FILE\T1ARRAY\TT09(C2M)\20171024\T1_TFTR2_20171024121519
            this.defectAndIndexFileDirectory = string.Format(@"EDA\FILE\{0}\{1}({2})\{3}\{4}", _sourceShop, destShop, destShopArea, shiftDate, sourceShopDescStepDirectory);
            ////EDA\FILE\T1ARRAY\TT09(C2M)\20171024\T1_TFTR2_20171024121519\T1_TFTR2_20171024121519.ZIP
            this.zipFileName = string.Format(@"EDA\FILE\{0}\{1}({2})\{3}\{4}\{4}.ZIP", _sourceShop, destShop, destShopArea, shiftDate, sourceShopDescStepDirectory);
        }

        public string MappMsg
        {
            get { return mappMsg; }
        }

        public void Execute()
        {
            try
            {
                InitData();//初始化資料

                if (TotalLaserDefectInfo.Rows.Count > 0) //有defect資訊才產檔
                {
                    GenerateDefectFile();//產生MQ File
                    GenerateIndexFile();//產生Index File
                    ZIPDefectFile(defectAndIndexFileDirectory);//壓縮
                    //UploadToFtpServer(zipFileName, "10.56.195.215", "anonymous", "");//上傳ftp
                }

                //SendMail();//寄信
                SendMapp(GetTransferMappMsg(true));//寄Mapp

                try
                {
                    DeleteDirectory(string.Format(@"EDA\FILE\{0}\{1}({2})", sourceShop + sourceFab, destShop, destShopArea), 7);//purge超過7天的資料夾
                }
                catch (Exception ex)
                {
                    SendMapp(GetDelDirectoryMappMsg(ex));
                }
            }
            catch (Exception ex)
            {
                SendMapp(GetTransferMappMsg(false));
                throw ex;
            }
        }

        private void GetDestShopArea()
        {
            //取得shipshop的 area 資料
            string sqlStr = @"select t.shiipping_shop,shop_desc from td_lcm_shipping_shop t where t.trans_shop='{0}' and rownum=1";
            sqlStr = string.Format(sqlStr, destShop);
            DataTable dataTable = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("EDA DB", sqlStr));

            if (dataTable.Rows.Count > 0)
            {
                destShopArea = dataTable.Rows[0]["shiipping_shop"].ToString();
                destShopDesc = dataTable.Rows[0]["shop_desc"].ToString();
            }
            else
                throw new Exception("no shipping area data");
        }

        private void InitData()
        {
            GetTotalDefectInfo();//取得全部Glass的Defect資料
            GetTotalLaserEqInfo();//取得全部Glass的Laser機台資料
            GetTotalTestEqInfo();//取得全部Glass的Test機台資料
            GetTotalCVDEqInfo();//取得全部Glass的Cvd機台資料
        }

        private void GenerateDefectFile()
        {
            DataRow[] foundRows;
            GetTotalGlassChipInfo();//取得所有glass & chip data,為產生 defect file

            foreach (DataRow dr in TotalGlassInfo.Rows)
            {
                GetGlassEqInfo(dr["glass_id"].ToString());//先利用 glass 去取得相關機台資訊

                foundRows = TotalChipInfo.Select("glass_id='" + dr["glass_id"].ToString() + "'");//取得glass的chip資料準備產生defect file
                for (int i = 0; i < foundRows.Length; i++)
                {
                    StreamWriter outputFile = CreateFile(foundRows[i]["chip_id"].ToString());//產生檔案
                    GenerateFileContent(outputFile, foundRows[i]["glass_id"].ToString(), foundRows[i]["chip_id"].ToString());//產生檔案內容
                    CloseFile(outputFile);//關檔  
                }
            }
        }

        private void GetTotalGlassChipInfo()
        {
            //DataView dv = TotalLaserDefectInfo.DefaultView;
            //dv.Sort = "GLASS_ID, CHIP_ID";
            TotalChipInfo = TotalLaserDefectInfo.DefaultView.ToTable(true, "GLASS_ID", "CHIP_ID");
            TotalGlassInfo = TotalChipInfo.DefaultView.ToTable(true, "GLASS_ID");
        }

        private void GetGlassEqInfo(string glassId)
        {
            //先利用 glass 去取得相關機台資訊
            GetGlassCVDEq(glassId);
            GetGlassTestEq(glassId);
            GetGlassLaserEq(glassId);
        }

        private void GetGlassCVDEq(string glassId)
        {
            DataRow[] foundRows = TotalCVDEqInfo.Select("glass_id='" + glassId + "'");

            if (foundRows.Length == 0)
            {
                cvdEqId = "*********";//9碼
                cvdEqStartTime = "**************";//14碼
                cvdEqEndTime = "**************";//14碼
                cvdOperator = "******";//6碼
            }
            else
            {
                cvdEqId = string.IsNullOrEmpty(foundRows[0]["cvd_eqid"].ToString()) ? "*********" : foundRows[0]["cvd_eqid"].ToString().PadRight(9, ' ').Substring(0, 9);
                cvdEqStartTime = string.IsNullOrEmpty(foundRows[0]["cvd_starttime"].ToString()) ? "**************" : foundRows[0]["cvd_starttime"].ToString().PadRight(14, ' ').Substring(0, 14);
                cvdEqEndTime = string.IsNullOrEmpty(foundRows[0]["cvd_endtime"].ToString()) ? "**************" : foundRows[0]["cvd_endtime"].ToString().PadRight(14, ' ').Substring(0, 14);
                cvdOperator = string.IsNullOrEmpty(foundRows[0]["cvd_operator_id"].ToString()) ? "******" : foundRows[0]["cvd_operator_id"].ToString().PadRight(6, ' ').GetLast(6);
            }
        }

        private void GetGlassTestEq(string glassId)
        {
            DataRow[] foundRows = TotalTestEqInfo.Select("glass_id='" + glassId + "'");

            if (foundRows.Length == 0)
            {
                testEqId = "*********";//9碼
                testEqStartTime = "**************";//14碼
                testEqEndTime = "**************";//14碼
            }
            else
            {
                testEqId = string.IsNullOrEmpty(foundRows[0]["test_eqid"].ToString()) ? "*********" : foundRows[0]["test_eqid"].ToString().PadRight(9, ' ').Substring(0, 9);
                testEqStartTime = string.IsNullOrEmpty(foundRows[0]["test_starttime"].ToString()) ? "**************" : foundRows[0]["test_starttime"].ToString().PadRight(14, ' ').Substring(0, 14);
                testEqEndTime = string.IsNullOrEmpty(foundRows[0]["test_endtime"].ToString()) ? "**************" : foundRows[0]["test_endtime"].ToString().PadRight(14, ' ').Substring(0, 14);
            }
        }

        private void GetGlassLaserEq(string glassId)
        {
            DataRow[] foundRows = TotalLaserEqInfo.Select("glass_id='" + glassId + "'");

            if (foundRows.Length == 0)
            {
                laserEqId = "*********";//9碼
                laserEqStartTime = "**************";//14碼
                laserEqEndTime = "**************";//14碼
                laserOperator = "********";//8碼
            }
            else
            {
                laserEqId = string.IsNullOrEmpty(foundRows[0]["laser_eqid"].ToString()) ? "*********" : foundRows[0]["laser_eqid"].ToString().PadRight(9, ' ').Substring(0, 9);
                laserEqStartTime = string.IsNullOrEmpty(foundRows[0]["laser_starttime"].ToString()) ? "**************" : foundRows[0]["laser_starttime"].ToString().PadRight(14, ' ').Substring(0, 14);
                laserEqEndTime = string.IsNullOrEmpty(foundRows[0]["laser_endtime"].ToString()) ? "**************" : foundRows[0]["laser_endtime"].ToString().PadRight(14, ' ').Substring(0, 14);
                laserOperator = string.IsNullOrEmpty(foundRows[0]["laser_operator_id"].ToString()) ? "********" : foundRows[0]["laser_operator_id"].ToString().PadRight(8, ' ').Substring(0, 8);
            }
        }

        private StreamWriter CreateFile(string chipId)
        {
            string defectFileDirectory = string.Format(@"{0}\{1}\{2}", defectAndIndexFileDirectory, chipId.Substring(0, 5), chipId.Substring(0, 8));
            if (!Directory.Exists(defectFileDirectory))
            {
                Directory.CreateDirectory(defectFileDirectory);
            }

            //將index 檔案路徑資料紀錄下來,為製作 index file
            indexArray.Add(DateTime.Now.ToString("HHmmss") + " " + string.Format(@"{0}\{1}\{2}\{3}.TXT", sourceShopDescStepDirectory, chipId.Substring(0, 5), chipId.Substring(0, 8), chipId));

            return new StreamWriter(defectFileDirectory + string.Format(@"\{0}.TXT", chipId));
        }

        private void GenerateFileContent(StreamWriter outputFile, string glassId, string chipId)
        {
            //Header=>0:Panel ID,1:PRODUCT_ID ID,2:Test EQUIP_ID,3:Test TRACK_IN_TIME,4:Test TRACK_OUT_TIME,
            //5:Repair 機台編號,6:Repair 機台TA 工號,7:Repair 機台TRACK_IN_TIME,8:Repair 機台TRACK_OUT_TIME,9:P,E 量產品或是實驗品
            //10:CVD 機台編號,11:CVD 機台TA 工號,12:CVD 機台TRACK_IN_TIME,13:CVD 機台TRACK_OUT_TIME,14:GLASS_ID
            string header = @"T G {0} G  **** {1} {2} {3} {4} {5} {6} {7} {8} {9} *********** {10} {11} {12} {13} ********* ****** ************** ************** {14}";

            string column = @">No Data  Gate  Code Repr Deft Ty RT T1   T2 R Analysis Mod ADC    DefectPictureName       Code Repr Deft Ty RT DefectPictureName   ";

            //Content=>0:Defect no,1:S,2:G,3:Defect,4:reason,5:RT,6:AC/AOI
            string content = @"{0} {1} {2} {3} {4} {5} {6} ** * OTHERS       *      *********************** **** ************ ** ***********************";
            string tempContent = string.Empty;

            string footer = @"@";

            //取得defect資料
            DataRow[] foundRows = TotalLaserDefectInfo.Select("glass_id='" + glassId + "' and chip_id='" + chipId + "'");
            //過濾重複的defect code
            DataTable dataTable = ConvertDataRowToDataTable(foundRows);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                if (i == 0)
                {
                    header = string.Format(header, chipId, dataTable.Rows[i]["product_id"].ToString(), testEqId, testEqStartTime, testEqEndTime, laserEqId, laserOperator, laserEqStartTime, laserEqEndTime, dataTable.Rows[i]["lot_type"].ToString(), cvdEqId, cvdEqStartTime, cvdEqEndTime, cvdOperator, glassId);
                    outputFile.WriteLine(header);
                    outputFile.WriteLine(column);
                }
                tempContent = string.Format(content, String.Format("{0:000}", i + 1), dataTable.Rows[i]["s"].ToString(), dataTable.Rows[i]["g"].ToString(), dataTable.Rows[i]["RETYPE"].ToString(), dataTable.Rows[i]["reason"].ToString(), dataTable.Rows[i]["rt"].ToString(), dataTable.Rows[i]["filetype"].ToString());
                outputFile.WriteLine(tempContent);
            }
            outputFile.WriteLine(footer);
        }

        //當月底時會將 prod eda 待purge的月資料,先複製一份到歷史區,所以會有段時間某些資料會同時間存在,
        //所以需要過濾重複的資料
        private DataTable ConvertDataRowToDataTable(DataRow[] rowArray)
        {
            DataTable dataTable = rowArray.CopyToDataTable();
            return dataTable.DefaultView.ToTable(true, "product_id", "lot_type", "repr_EQUIP_ID", "REPR_STARTTIME", "REPR_ENDTIME", "s", "g", "RETYPE", "reason", "rt", "filetype", "defect_judge", "defect_result");
        }

        private void CloseFile(StreamWriter outputFile)
        {
            outputFile.Close();
            outputFile.Dispose();
        }

        private void GenerateIndexFile()
        {
            string indexFileDirectory = string.Format(@"{0}\index", defectAndIndexFileDirectory);
            if (!Directory.Exists(indexFileDirectory))
            {
                Directory.CreateDirectory(indexFileDirectory);
            }
            //因為有使用using,所以會自動關檔 & dispose
            using (StreamWriter sr = new StreamWriter(indexFileDirectory + string.Format(@"\{0}.TXT", shiftDate)))
            {
                foreach (string s in indexArray)
                {
                    sr.WriteLine(s);
                }
            }
        }

        // 傳入參數: 來源路徑
        private void ZIPDefectFile(string dir)
        {
            ZipFiles.SharpZip(dir, 1);
            //ZipFiles.IonicZip(dir, 1);
            //ZipFiles.ZipExe(dir);
        }

        private void UploadToFtpServer(string filename, string ftpServerIP, string account, string ftppassword)
        {
            FileInfo fileInf = new FileInfo(filename);
            string serverPath = string.Format("/{1}/COMPRESSED_FILE/", ftpServerIP, destShopArea, fileInf.Name);

            FtpFiles ftp = new FtpFiles(ftpServerIP, account, ftppassword);
            bool success = ftp.FtpUpload(filename, serverPath);

            if (!success)
                throw new Exception("Upload to FTP:" + ftp.ErrorMessage);
        }

        private void SendMail()
        {
            Mail mail = new Mail();
            string subject = "【CIM電子報】北廠 Defect MQ 檔案傳送通知";
            string mailBody = string.Empty;

            if (indexArray.Count > 0)
            {
                mailBody = @"
                        Dear Sir,<br><br>  
                        ShiftDate:{0}，{1} 因出貨至 {2}({3}_{4}) ，需傳送 {5} 修補資訊，共 {6} 個 Defect MQ 檔案，Zip File Size is {7}。<br>
                                  謝謝。";
            }
            else
            {
                mailBody = @"
                        Dear Sir,<br><br>  
                        ShiftDate:{0}，{1} 今日未出貨至 {2}({3}_{4})。<br>
                        謝謝。";
            }
            mailBody = string.Format(mailBody, shiftDate, sourceShop, destShop, destShopArea, destShopDesc, sourceFab, indexArray.Count, GetZipFileSize());

            string sqlStr = @"select t.iv_reportmailuser from iv_rpt_reportmail t where t.iv_report_name='T1ArrayDefctFileToOutSite'";
            DataTable dataTable = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("Innoview DB", sqlStr));

            if (dataTable.Rows.Count > 0)
            {
                string toEmail = dataTable.Rows[0]["iv_reportmailuser"].ToString();
                mail.SendMail(subject, mailBody, null, null, toEmail);
            }
        }

        private string GetTransferMappMsg(bool success)
        {
            if (success)
            {
                //有出貨跟未出貨傳mapp訊息不一樣
                if (indexArray.Count > 0)
                    return string.Format(@"ShiftDate:{0}，{1} 因出貨至 {2}({3}_{4}) ，需傳送 {5} 修補資訊，共 {6} 個 Defect MQ 檔案，Zip File Size is {7}K。", shiftDate, sourceShop, destShop, destShopArea, destShopDesc, sourceFab, indexArray.Count, GetZipFileSize());
                else
                    return string.Format(@"ShiftDate:{0}，{1} 今日未出貨至 {2}({3}_{4})。", shiftDate, sourceShop, destShop, destShopArea, destShopDesc);
            }
            else
                return string.Format(@"ShiftDate:{0}，{1} 因出貨至 {2}({3}_{4}) ，傳送 {5} 修補資訊失敗，請確認!", shiftDate, sourceShop, destShop, destShopArea, destShopDesc, sourceFab);
        }

        private string GetZipFileSize()
        {
            FileInfo fileInfo = new FileInfo(this.zipFileName);

            if (!fileInfo.Exists) return "0";

            try
            {
                return string.Format("{0:n0}", (fileInfo.Length / 1024).ToString());
            }
            catch
            {
                return "0";
            }

        }

        private string GetDelDirectoryMappMsg(Exception ex)
        {
            return string.Format(@"Purge 出貨修補檔案超過保留期限的資料夾失敗:{0}", ex.Message);
        }

        private void SendMapp(string msg)
        {
            mappMsg = msg;
            RequestDTO requestDTO = new RequestDTO();
            requestDTO.Account = "api_jncim1_mi";
            requestDTO.APIKey = "B195F0D2-7AFF-0F08-41A0-48386C54DE70";
            requestDTO.ContentType = MessageType.TextMessage;
            //mi alarm 聊天室
            requestDTO.ChatSn = "12938";
            requestDTO.MsgContent = msg;

            MappMessage mappMessage = MappFactory.CreateMappMessage(requestDTO);
            ResponseDTO responseDTO = mappMessage.Send();
        }

        private void DeleteDirectory(string targetDir, int keepDays)
        {
            DateTime today = DateTime.Now;
            DateTime dirDate;
            string[] dirs = Directory.GetDirectories(targetDir);

            foreach (string dir in dirs)
            {
                DirectoryInfo dirInfo = new DirectoryInfo(dir);
                dirDate = Convert.ToDateTime(dirInfo.Name.Substring(0, 4) + "/" + dirInfo.Name.Substring(4, 2) + "/" + dirInfo.Name.Substring(6, 2));

                if ((today - dirDate).Days > keepDays)
                {
                    Directory.Delete(dirInfo.ToString(), true);
                }
            }
        }

        //取得出貨片子的defect資訊,包含正式區和歷史區
        private void GetTotalDefectInfo()
        {
            string sqlStr = @"select a.step_id, a.GLASS_ID,'Y'||SUBSTR(b.CHIP_ID,7,20) as CHIP_ID ,
               RPAD(RTRIM(c.item3), 4, ' ') as lot_type,a.LOT_ID,
               RPAD(RTRIM(a.PRODUCT_ID), 8, ' ') as PRODUCT_ID,
               RPAD(RTRIM(a.EQUIP_ID), 9, ' ') as repr_EQUIP_ID,
               to_char(nvl(a.DATE_ITEM1,a.GLASS_START_TIME),'yyyyMMddHH24MISS') as REPR_STARTTIME,
               to_char(a.GLASS_START_TIME,'yyyyMMddHH24MISS') as REPR_ENDTIME,
               RPAD(RTRIM(a.ITEM2), 8, ' ') as operator_id,
               b.item4 as defect_judge,
               b.item5 as defect_result,
               LPAD(LTRIM(s), 5, '0') as s,
               LPAD(LTRIM(g), 5, '0') as g,
               substr(b.Item2,2,10) as RETYPE,
               RPAD(RTRIM(substr(b.Item52,0,4)), 4, ' ') as FILETYPE,
               case when substr(b.item51,0,12) is null then '************'
               else RPAD(RTRIM(substr(b.item51,0,12)), 12, ' ') end as reason,
               case when b.Item2 in ('PAD91','PAD9T') then '**'
                    when b.item4='AR' and replace(b.item5,'-','')='2DP' then 'D '
                    when b.item4='AR' and replace(b.item5,'-','')='DP' then 'N '
                    when b.item4='AR' and replace(b.item5,'-','')='NP' then 'G '
                    when b.item4='AR' and replace(b.item5,'-','')='BP' then 'B '
                    when b.item4='NR' and replace(b.item5,'-','')='NP' then 'G '
                    when b.item4='NR' and replace(b.item5,'-','')='' then 'G '
                    when b.item4='F'  then 'B '
                    when b.item4='MD' then 'X '
                    when b.item4='CP' then 'L '
                    when b.item4='CR' then 'L '
                    when b.item4='NR' and replace(b.item5,'-','')='BP' then 'B '
                    when b.item4='NR' and replace(b.item5,'-','')='DP' then 'N '
               else '**' end as RT
               from lcdsys.array_glass_t a,lcdsys.array_defect_t b,lcdsys.array_glass_hst_t c
               where a.glass_id in 
               ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
               )
               and a.step_id in 
               (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.Laser_Repair_01','STEP_GROUP.SD_Laser_CVD','STEP_GROUP.Test_L_CVD')
               )
               --and a.glass_id='AB0G1AH20HD023' 
               and a.step_id=b.step_id
               and a.glass_id=b.glass_id
               and a.glass_start_time=b.glass_start_time
               and a.glass_id=c.glass_id
               and a.step_id=c.step_id
               and b.ITEM2 <> '-'
               
               union all
 
               select a.step_id, a.GLASS_ID,'Y'||SUBSTR(b.CHIP_ID,7,20) as CHIP_ID ,
               RPAD(RTRIM(c.item3), 4, ' ') as lot_type,a.LOT_ID,
               RPAD(RTRIM(a.PRODUCT_ID), 8, ' ') as PRODUCT_ID,
               RPAD(RTRIM(a.EQUIP_ID), 9, ' ') as repr_EQUIP_ID,
               to_char(nvl(a.DATE_ITEM1,a.GLASS_START_TIME),'yyyyMMddHH24MISS') as REPR_STARTTIME,
               to_char(a.GLASS_START_TIME,'yyyyMMddHH24MISS') as REPR_ENDTIME,
               RPAD(RTRIM(a.ITEM2), 8, ' ') as operator_id,
               b.item4 as defect_judge,
               b.item5 as defect_result,
               LPAD(LTRIM(s), 5, '0') as s,
               LPAD(LTRIM(g), 5, '0') as g,
               substr(b.Item2,2,10) as RETYPE,
               RPAD(RTRIM(substr(b.Item52,0,4)), 4, ' ') as FILETYPE,
               case when substr(b.item51,0,12) is null then '************'
               else RPAD(RTRIM(substr(b.item51,0,12)), 12, ' ') end as reason,
               case when b.Item2 in ('PAD91','PAD9T') then '**'
                    when b.item4='AR' and replace(b.item5,'-','')='2DP' then 'D '
                    when b.item4='AR' and replace(b.item5,'-','')='DP' then 'N '
                    when b.item4='AR' and replace(b.item5,'-','')='NP' then 'G '
                    when b.item4='AR' and replace(b.item5,'-','')='BP' then 'B '
                    when b.item4='NR' and replace(b.item5,'-','')='NP' then 'G '
                    when b.item4='NR' and replace(b.item5,'-','')='' then 'G '
                    when b.item4='F'  then 'B '
                    when b.item4='MD' then 'X '
                    when b.item4='CP' then 'L '
                    when b.item4='CR' then 'L '
                    when b.item4='NR' and replace(b.item5,'-','')='BP' then 'B '
                    when b.item4='NR' and replace(b.item5,'-','')='DP' then 'N '
               else '**' end as RT
               from lcdsys.array_glass_t@edarpt2hst a,lcdsys.array_defect_t@edarpt2hst b,lcdsys.array_glass_hst_t@edarpt2hst c
               where a.glass_id in 
               ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
               )
               and a.step_id in 
               (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.Laser_Repair_01','STEP_GROUP.SD_Laser_CVD','STEP_GROUP.Test_L_CVD')
               )
               --and a.glass_id='AB0G1AH20HD023' 
               and a.step_id=b.step_id
               and a.glass_id=b.glass_id
               and a.glass_start_time=b.glass_start_time
               and a.glass_id=c.glass_id
               and a.step_id=c.step_id
               and b.ITEM2 <> '-'";

            sqlStr = string.Format(sqlStr, destShop, shiftDateTimeBefore, shiftDateTime, sourceShop);

            TotalLaserDefectInfo = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("EDA DB", sqlStr));

        }

        //取得出貨片子的laser eq資訊,包含正式區和歷史區
        private void GetTotalLaserEqInfo()
        {
            string sqlStr = @"select t.glass_id,t.equip_id as laser_eqid,to_char(nvl(t.DATE_ITEM1,t.GLASS_START_TIME),'yyyyMMddHH24MISS') as laser_starttime,to_char(t.glass_start_time,'yyyyMMddHH24MISS') as laser_endtime,t.ITEM2 as laser_operator_id 
                from lcdsys.array_glass_t t
                where t.glass_id in 
                ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
                )
                and t.step_id in 
                (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.Laser_Repair_01')
                )

                union all

                select t.glass_id,t.equip_id as laser_eqid,to_char(nvl(t.DATE_ITEM1,t.GLASS_START_TIME),'yyyyMMddHH24MISS') as laser_starttime,to_char(t.glass_start_time,'yyyyMMddHH24MISS') as laser_endtime,t.ITEM2 as laser_operator_id 
                from lcdsys.array_glass_t@edarpt2hst t
                where t.glass_id in 
                ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
                )
                and t.step_id in 
                (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.Laser_Repair_01')
                )";

            sqlStr = string.Format(sqlStr, destShop, shiftDateTimeBefore, shiftDateTime, sourceShop);

            TotalLaserEqInfo = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("EDA DB", sqlStr));
        }

        //取得出貨片子的test eq資訊,包含正式區和歷史區
        private void GetTotalTestEqInfo()
        {
            string sqlStr = @"select t.glass_id,t.equip_id as test_eqid,to_char(nvl(t.DATE_ITEM1,t.GLASS_START_TIME),'yyyyMMddHH24MISS') as test_starttime,to_char(t.glass_start_time,'yyyyMMddHH24MISS') as test_endtime
                from lcdsys.array_glass_t t
                where t.glass_id in 
                ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
                )
                and t.step_id in 
                (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.Array_Test_01')
                )

                union all

                select t.glass_id,t.equip_id as test_eqid,to_char(nvl(t.DATE_ITEM1,t.GLASS_START_TIME),'yyyyMMddHH24MISS') as test_starttime,to_char(t.glass_start_time,'yyyyMMddHH24MISS') as test_endtime
                from lcdsys.array_glass_t@edarpt2hst t
                where t.glass_id in 
                ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
                )
                and t.step_id in 
                (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.Array_Test_01')       
                )";

            sqlStr = string.Format(sqlStr, destShop, shiftDateTimeBefore, shiftDateTime, sourceShop);

            TotalTestEqInfo = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("EDA DB", sqlStr));
        }

        //取得出貨片子的cvd eq資訊,包含正式區和歷史區
        private void GetTotalCVDEqInfo()
        {
            string sqlStr = @"select t.glass_id,t.equip_id as cvd_eqid,to_char(nvl(t.DATE_ITEM1,t.GLASS_START_TIME),'yyyyMMddHH24MISS') as cvd_starttime,to_char(t.glass_start_time,'yyyyMMddHH24MISS') as cvd_endtime,t.ITEM2 as cvd_operator_id 
                from lcdsys.array_glass_t t
                where t.glass_id in 
                ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
                )
                and t.step_id in 
                (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.SD_Laser_CVD','STEP_GROUP.Test_L_CVD')
                )

                union all

                select t.glass_id,t.equip_id as cvd_eqid,to_char(nvl(t.DATE_ITEM1,t.GLASS_START_TIME),'yyyyMMddHH24MISS') as cvd_starttime,to_char(t.glass_start_time,'yyyyMMddHH24MISS') as cvd_endtime,t.ITEM2 as cvd_operator_id 
                from lcdsys.array_glass_t@edarpt2hst t
                where t.glass_id in 
                ( 
                  select distinct 
                  case when t1.gsflag='CHIP' then substr(t1.glassid,0,14)
                  when t1.gsflag='CUT' then substr(t1.glassid,0,14)
                  else t1.glassid end transfer_subid
                  from td_wms_shipping_file t, mfginfo@eda2tclmes t1,td_lcm_shipping_shop t2
                  where t.carton_id=t1.carton_id
                  and t.mes_ship_date=t1.mes_ship_date
                  and t.shippingdate>='{1}'
                  and t.shippingdate<'{2}'
                  and t.shippingfrom = '{3}'
                  and t.sites = '{0}'
                  and t.sites=t2.trans_shop
                )
                and t.step_id in 
                (
                  select a.param_value from onepage_config_t a
                  where a.param_name in ('STEP_GROUP.SD_Laser_CVD','STEP_GROUP.Test_L_CVD')
                )";

            sqlStr = string.Format(sqlStr, destShop, shiftDateTimeBefore, shiftDateTime, sourceShop);

            TotalCVDEqInfo = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("EDA DB", sqlStr));
        }
    }

    //string 的擴充方法
    public static class StringExtension
    {
        public static string GetLast(this string source, int tail_length)
        {
            if (tail_length >= source.Length)
                return source;
            return source.Substring(source.Length - tail_length);
        }
    }
}
