﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Innolux.Portal.Common.MailClass;
using Common.Logging;
using Newtonsoft.Json;
using Quartz.CustomJob.Base;

namespace Quartz.CustomJob.WH
{
    public class PersonJob : JobBsae
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(StockUtilJob));
        WebReference.AOEWS ws = new WebReference.AOEWS();
        BisSQL.BusinessSQL biSql = new BisSQL.BusinessSQL();

        public override void Execute(IJobExecutionContext context)
        {
            try
            {
                string alarmText = String.Empty;
                int alarmLevel = 80;
                logger.Info(context.JobDetail.JobType.ToString() + " running... " + "Job|Trigger Info:[" + context.Trigger.JobKey.Name + "/" + context.Trigger.JobKey.Group + "|" + context.Trigger.Key.Name +"/" + context.Trigger.Key.Group+"]");
                
                DateTime createDateTime = DateTime.Now;
                string sDayNight = (createDateTime.Hour > 17) ? "夜" : "日";

                DataTable dt = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("WH DB", biSql.GetCardData(sDayNight)).Trim());
                //string stock = dt.Rows[0][0].ToString();
                foreach (DataRow dr in dt.Rows)
                {
                    alarmText = dr[0].ToString() + " 未打卡人員： " + dr[1].ToString();
                    string fileName = string.Format("{0}_xml_{1}.xml", DateTime.Now.ToString("yyyyMMdd_HHmmss"), System.Guid.NewGuid());
                    string fullFileName = this.GetFileFullName(fileName);

                    Innolux.Portal.Common.MailClass.XmlTemplate template = new Innolux.Portal.Common.MailClass.XmlTemplate();
                    template.FabID = dr[0].ToString();
                    template.SysType = "AUTOREPORT";
                    template.EqID = "WH";
                    template.AlarmID = dr[0].ToString()+"WH_MappJob";
                    template.AlarmText = "人員管控:";
                    template.AlarmCommentValue = alarmText;
                    template.OperatorName = "WH";

                    string content = template.GetTemplate(string.Empty, Innolux.Portal.Common.ReportFrequency.Mintue);
                    template.ToSaveXml(fullFileName, content);

                    logger.Info("Start Upload to FTP... ");
                    Innolux.Portal.Common.FileClass.FtpFiles ftp = new Innolux.Portal.Common.FileClass.FtpFiles();
                    bool b = ftp.FtpUpload(fullFileName);
                    if (b == true)
                    {
                        logger.Info("End Upload to FTP... ");
                        try
                        {
                            logger.Info("Delete File:" + fullFileName);
                            Innolux.Portal.Common.FileClass.FileHelper.FileDel(fullFileName);
                        }
                        catch (Exception ex)
                        {
                            logger.Error("Delete File Error:" + ex.Message);
                        }
                    }
                    else
                    {
                        logger.Error(ftp.ErrorMessage);
                    }
                }
                
                /* Mail*/
//                Mail mail = new Mail();
//                string sSubject = "[CIM電子報]T2-CIM " + DateTime.Now.ToString("yyyy/MM/dd") + " 測試...";
//                string sMailBody = @"
//                Dear Sir,<br>T2 CIM萬歲，颱風假...";
//                mail.SendMail(sSubject, sMailBody, null, null, "Ryan.lin@innolux.com");
                
//                logger.Info(context.JobDetail.JobType.ToString() + " run finished... ");
                
            }
            catch (Exception ex)
            {
                logger.Error("Job Error:"+ex.Message);
                throw ex;
            }
        }
    }
}
