using System;
using System.Threading;
using Common.Logging;
using Quartz.CustomJob.Base;

namespace Quartz.CustomJob.WH
{
    /// <summary>
    /// A sample job that just prints info on console for demostration purposes.
    /// </summary>
    public class TestJob2 : JobBsae
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(TestJob2));

        /// <summary>
        /// Called by the <see cref="IScheduler" /> when a <see cref="ITrigger" />
        /// fires that is associated with the <see cref="IJob" />.
        /// </summary>
        /// <remarks>
        /// The implementation may wish to set a  result object on the 
        /// JobExecutionContext before this method exits.  The result itself
        /// is meaningless to Quartz, but may be informative to 
        /// <see cref="IJobListener" />s or 
        /// <see cref="ITriggerListener" />s that are watching the job's 
        /// execution.
        /// </remarks>
        /// <param name="context">The execution context.</param>
        public override void Execute(IJobExecutionContext context)
        {
            logger.Info("TestJob2 running...");
            Thread.Sleep(TimeSpan.FromSeconds(5));
            logger.Info("TestJob2 run finished.");
        }
    }
}