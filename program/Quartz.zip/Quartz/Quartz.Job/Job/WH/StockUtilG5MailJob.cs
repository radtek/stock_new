﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Innolux.Portal.Common.MailClass;
using Common.Logging;
using Newtonsoft.Json;
using Quartz.CustomJob.Base;

namespace Quartz.CustomJob.WH
{
    public class StockUtilG5MailJob : JobBsae
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(StockUtilJob));
        WebReference.AOEWS ws = new WebReference.AOEWS();
        BisSQL.BusinessSQL biSql = new BisSQL.BusinessSQL();

        public override void Execute(IJobExecutionContext context)
        {
            try
            {//T1WH_StockMailJob
                string alarmTitle = String.Empty;
                string alarmText = String.Empty;
                int alarmLevel = 95;
                logger.Info(context.JobDetail.JobType.ToString() + " running... " + "Job|Trigger Info:[" + context.Trigger.JobKey.Name + "/" + context.Trigger.JobKey.Group + "|" + context.Trigger.Key.Name + "/" + context.Trigger.Key.Group + "]");

                DataTable dt = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("WH DB", biSql.GetWHStockUtilG5Mail()).Trim());
                string stockname = dt.Rows[0][0].ToString();
                double now_count = double.Parse(dt.Rows[0][1].ToString());
                double now_stocksize = now_count * 2.76;
                double stock_count = double.Parse(dt.Rows[0][2].ToString());
                double stock_stocksize = stock_count * 2.76;
                double stock_ratio = double.Parse(dt.Rows[0][3].ToString());
                double monitor_ratio = double.Parse(dt.Rows[0][4].ToString());
                string monitorratio = monitor_ratio * 100 + "%";
                if (stock_ratio >= monitor_ratio)
                {
                //    logger.Info(context.JobDetail.JobType.ToString() + " Alarm Start... ");


                //    alarmTitle = "[Stock Alarm] " + stockname + "儲區使用率已達" + monitorratio + "以上通知";


                //    string sMailBody = @"Dear Sir,\n\n {0}儲區最大可儲放{1}板({2}m2)，已儲放{3}板({4}m2)，使用率已達{5}以上。\n"+
                //        "一、請PP協助提供G5優先出貨料號給MFG。\n"+
                //        "二、請MFG依PP提供G5優先出貨料號入庫，其餘G5料號暫勿入庫。\n"+
                //        "三、請IE重新評估{0}儲放位置。\n"+
                //         "謝謝。";
                //    sMailBody = string.Format(sMailBody, stockname, stock_count, stock_stocksize, now_count, now_stocksize, monitorratio);


                //    string fileName = string.Format("{0}_xml_{1}.xml", DateTime.Now.ToString("yyyyMMdd_HHmmss"), System.Guid.NewGuid());
                //    string fullFileName = this.GetFileFullName(fileName);

                //    Innolux.Portal.Common.MailClass.XmlTemplate template = new Innolux.Portal.Common.MailClass.XmlTemplate();
                //    template.FabID = "T1";
                //    template.SysType = "AUTOREPORT";
                //    template.EqID = "WH";
                //    template.AlarmID = "T1WH_StockMailJob";
                //    template.AlarmText = alarmTitle;// "儲區管控:";
                //    template.AlarmCommentValue = sMailBody;
                //    template.OperatorName = "WH";

                //    string content = template.GetTemplate(string.Empty, Innolux.Portal.Common.ReportFrequency.Mintue);
                //    template.ToSaveXml(fullFileName, content);

                //    logger.Info("Start Upload to FTP... ");
                //    Innolux.Portal.Common.FileClass.FtpFiles ftp = new Innolux.Portal.Common.FileClass.FtpFiles();
                //    bool b = ftp.FtpUpload(fullFileName);
                //    if (b == true)
                //    {
                //        logger.Info("End Upload to FTP... ");
                //        try
                //        {
                //            logger.Info("Delete File:" + fullFileName);
                //            Innolux.Portal.Common.FileClass.FileHelper.FileDel(fullFileName);
                //        }
                //        catch (Exception ex)
                //        {
                //            logger.Error("Delete File Error:" + ex.Message);
                //        }
                //    }
                //    else
                //    {
                //        logger.Error(ftp.ErrorMessage);
                //    }


                    /* Mail*/
                    
                    string toEmail = "",ccEmail = "";
                    Mail mail = new Mail();
                    string sSubject = "[Stock Alarm] " + stockname + "儲區使用率已達" + monitorratio + "以上通知";
                    string sMailBody = @"
                        Dear Sir,<br><br>  
                        {0}儲區最大可儲放{1}板({2} m2)，已儲放{3}板({4} m2)，使用率已達{5}以上。<br>
                          一、請PP協助提供G5優先出貨料號給MFG。<br>
                          二、請MFG依PP提供G5優先出貨料號入庫，其餘G5料號暫勿入庫。<br>
                          三、請IE重新評估{0}儲放位置。<br>
                                  謝謝。";
                    sMailBody = string.Format(sMailBody, stockname, stock_count, stock_stocksize, now_count, now_stocksize, monitorratio);

                    DataTable dtMail = JsonConvert.DeserializeObject<DataTable>(ws.GetJsonStr("WH DB", biSql.SetMailInfo("StockUtilG5MailJob")).Trim());
                    foreach (DataRow dr in dtMail.Rows)
                    {
                        if (dr[0].ToString() == "TO")
                        {
                            toEmail = dr[1].ToString();
                        }
                        if (dr[0].ToString() == "CC")
                        {
                            ccEmail = dr[1].ToString();
                        }
                    }
                    if (ccEmail == "")
                    {
                        logger.Info(context.JobDetail.JobType.ToString() + " mail to" + toEmail);
                        mail.SendMail(sSubject, sMailBody, null, null, toEmail);
                    }
                    else
                    {
                        if (toEmail != "")
                        {
                            logger.Info(context.JobDetail.JobType.ToString() + " mail to " + toEmail + " cc to " + ccEmail);
                            mail.SendMail(sSubject, sMailBody, null, null, toEmail, ccEmail);
                        }
                    }
                    logger.Info(context.JobDetail.JobType.ToString() + " run finished... ");
                   
                }
                else
                {
                    logger.Info(context.JobDetail.JobType.ToString() + " No Out of spec... ");
                
                }
                
               
                
            }
            catch (Exception ex)
            {
                logger.Error("Job Error:"+ex.Message);
                throw ex;
            }
        }
    }
}
