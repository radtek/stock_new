﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quartz.CustomJob.Job.Scheduler
{
    /// <summary>
    /// Report log, write report schedule execute log 
    /// </summary>
    public class ReportLogProvider
    {
        private Guid identityId;
        private WebReference.AOEWS ws = new WebReference.AOEWS();

        /// <summary>
        /// the report log identityID, it is GUID
        /// </summary>
        public ReportLogProvider()
        {
            this.identityId = Guid.NewGuid();
        }

        /// <summary>
        /// the report log constructor function
        /// </summary>
        /// <param name="id"></param>
        public ReportLogProvider(Guid id)
        {
            this.identityId = id;
        }

        /// <summary>
        /// write the report execute information to the database
        /// </summary>
        /// <param name="rptName">report name</param>
        /// <param name="triggerName">trigger name, </param>
        /// <param name="msg">the message content</param>
        /// <param name="processType">process type, can be defince by user</param>
        /// <param name="duration">duration</param>
        /// <param name="errorFlag">error flag</param>
        /// <param name="serverIP">execute report server IP</param>
        public void WriteLog(string rptName, string msg, string processType, string duration, string errorFlag, string serverIP)
        {
            #region SQL
            string sql = @"INSERT INTO IV_RPT_RUNLOG
									  (REPORT_NAME,
									   PROCESS_TYPE,
									   MESSAGE,
									   DURATION,
									   ERROR_FLAG,
									   SERVER_IP,
									   IDENTITY_ID)
									VALUES
									  ('{0}',
									   '{1}',
									   '{2}',
									   '{3}',
									   '{4}',
									   '{5}',
									   '{6}')";
            #endregion

            try
            {
                sql = string.Format(sql, rptName, processType, msg, duration, errorFlag, serverIP, this.identityId.ToString());
                ws.ExecuteNonQuery("Innoview DB", sql);
            }
            catch (Exception ex)
            {
            }
        }
    }
}