﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quartz.CustomJob.BisSQL
{
    class BusinessSQL
    {
        string sqlStr = "";
        public string GetWHStockUtil(int vAlarmLevel)
        {
            sqlStr = @"select fab,wmsys.wm_concat(area)
                       from (
                               select t1.fab,t2.area,round((nvl(t1.pcount,0)/t2.stock_count)*100,0) util
                               from (
                               select 'T1' fab,t2.area,
                                   round(sum(case when instr(t1.pallet_id,'A') = 1 then 1
                                         when instr(t1.pallet_id,'VN') = 1 then 2.3
                                         when instr(t1.pallet_id,'VA') = 1 then 2.3
                                         when instr(t1.pallet_id,'VH') = 1 then 2.3
                                         when instr(t1.pallet_id,'Q') = 1 then 1.5
                                         else 1
                                 end)) pcount
                               from jn_t1_wms.v_t1_wms_store_current_pallet@DW2T1WMS t1,wh_storage_area_spec t2
                               where instr(t1.bin,t2.area_spec) =1
                               and t2.fab = 'T1'
                               group by t2.area) t1, wh_storage_area t2
                               where t1.fab(+) = t2.fab
                               and t1.area(+) = t2.area
                               and t2.fab = 'T1'
                               union all
                               select 'T1' fab,t.area,round((t.used/total)*100,0) util
                               from (
                               select '自動倉' stock_type,
                                      decode(t.locationtype,3,substr(t.locationsize,-2),t.locationsize) area,
                                      count(*) total,sum(decode(t.locationstatus,1,1,0)) used
                               from jn_t1_wms.v_t1_wms_master@DW2T1WMS t
                               group by t.locationtype,t.locationsize) t
                               union 
                               select t2.fab,t2.area,round((nvl(t1.pcount,0)/t2.stock_count)*100,0) util
                               from (
                                       select fab,area,sum(pcount) pcount
                                       from(
                                       select 'T2' fab,t2.area,
                                           round(sum(case when instr(t1.pallet_id,'A') = 1 then 1
                                                   when instr(t1.pallet_id,'VN') = 1 then 2.3
                                                   when instr(t1.pallet_id,'VA') = 1 then 2.3
                                                   when instr(t1.pallet_id,'VH') = 1 then 2.3
                                                   when instr(t1.pallet_id,'Q') = 1 then 1.5
                                                   else 1
                                           end)) pcount
                                       from jn_t2_wms.v_t2_wms_store_current_pallet@DW2T2WMS t1,wh_storage_area_spec t2
                                       where instr(t1.bin,t2.area_spec) =1
                                       and t2.fab = 'T2'
                                       group by t2.area
                                       union all
                                       select 'T2' fab,t2.area,
                                           round(sum(case when instr(t1.pallet_id,'A') = 1 then 1
                                                   when instr(t1.pallet_id,'VN') = 1 then 2.3
                                                   when instr(t1.pallet_id,'VA') = 1 then 2.3
                                                   when instr(t1.pallet_id,'VH') = 1 then 2.3
                                                   when instr(t1.pallet_id,'Q') = 1 then 1.5
                                                   else 1
                                           end)) pcount
                                       from jn_t1_wms.v_t1_wms_store_current_pallet@DW2T1WMS t1,wh_storage_area_spec t2
                                       where instr(t1.bin,t2.area_spec) =1
                                       and t2.fab = 'T2'
                                       and t2.crossfabflag=1
                                       group by t2.area)
                                        group by fab,area) t1, wh_storage_area t2
                                where t1.fab(+) = t2.fab
                                and t1.area(+) = t2.area
                                and t2.fab = 'T2'
                                union all
                                select 'T2' fab,t.area,round((t.used/total)*100,0) util
                                from (
                                select decode(t.locationtype,0,'自動倉(板)',3,'自動倉(箱)') stock_type,
                                        decode(t.locationtype,3,substr(t.locationsize,-2),t.locationsize) area,
                                        count(*) total,sum(decode(t.locationstatus,1,1,0)) used
                                from jn_t2_wms.v_t2_wms_master@DW2T2WMS t
                                group by t.locationtype,t.locationsize) t)
                        where util >= {0}
                        group by fab";
            sqlStr = string.Format(sqlStr, vAlarmLevel);
            return sqlStr;
        }
        public string GetWHStockUtilG5Mail()
        {
            sqlStr = @"select t1.fab||' G5' stockname,sum(t1.pcount) pcount,nvl(sum(t2.stock_count),0) stock_count,
                            decode(nvl(sum(t2.stock_count),0),0,0,round(sum(t1.pcount)/sum(t2.stock_count),4)) stock_ratio, 
                            nvl(max(t3.fieldvalue),0) monitorratio
                       from (

                       select 'T1' fab,t2.area,
                           round(sum(case when instr(t1.pallet_id,'A') = 1 then 1
                                 when instr(t1.pallet_id,'VN') = 1 then 2.3
                                 when instr(t1.pallet_id,'VA') = 1 then 2.3
                                 when instr(t1.pallet_id,'VH') = 1 then 2.3
                                 when instr(t1.pallet_id,'Q') = 1 then 1.5
                                 else 1
                         end)) pcount
                       from jn_t1_wms.v_t1_wms_store_current_pallet@DW2T1WMS t1,wh_storage_area_spec t2
                       where instr(t1.bin,t2.area_spec) =1
                       and t2.fab = 'T1'
                       and t2.area in('3樓G5','4樓G5')
                       group by t2.area
                       ) t1, wh_storage_area t2,wh_fabtransfer_config t3
                       where t1.fab(+) = t2.fab
                       and t1.area(+) = t2.area
                       and t1.fab = 'T1'
                       and t3.fieldname='STOCKG5RATIO'
                        group by t1.fab ";
            return sqlStr;
        }
        public string GetCardData(string DayNight)
        {
            string sql = @"   select ee.fab,wm_concat(ee.cname) Personlist
                                 from(
                                 select decode(dd.groupid,20,'T2',30,'T2','T1') Fab,decode(sign(instr(aa.CTPROG,'日')),1,'日','夜') tprog,cc.cname
                                            from(
                                             select aa.pernr, aa.datum, aa.tprog,aa.CTPROG,aa.WORKHOUR,aa.worktime,min(aa.leavestart) leavestart,max(aa.leaveend) leaveend,sum(aa.leavehour) leavehour
                                            from(
                                             select trim(to_char(t1.pernr,'00000000')) pernr, t1.datum, t1.tprog ,
                                               decode(substr(t1.TPROG,1,3),'22D','日二輪','22N','夜二輪','31D','外籍日','31N','外籍夜','GED','常日') CTPROG,
                                               decode(substr(t1.TPROG,1,3),'GED',8,10) WORKHOUR,
                                               decode(substr(t1.TPROG,1,3),'22D',trunc(sysdate,'dd')+7/24+30/1440,'22N',trunc(sysdate,'dd')+19/24+30/1440,
                                                                           '31D',trunc(sysdate,'dd')+7/24+30/1440,'31N',trunc(sysdate,'dd')+19/24+30/1440,
                                                                           'GED',trunc(sysdate,'dd')+8/24) worktime,
                                               t2.begda+substr(t2.beguz,1,2)/24+substr(t2.beguz,4,2)/1440 leavestart,
                                               t2.endda+substr(t2.enduz,1,2)/24+substr(t2.enduz,4,2)/1440 leaveend,t2.stdaz leavehour
                                               from wh_mis_class t1 ,
                                               (
                                                 select trim(to_char(pernr,'00000000')) pernr, begda, beguz, endda, enduz, awart, awarttxt, stdaz, actype, status 
                                                 from wh_mis_leave t 
                                                 where  t.begda<=to_date(to_char(sysdate,'yyyymmdd'),'yyyymmdd')
                                                    and to_char(endda,'yyyymmdd')||' '||enduz>to_char( sysdate ,'yyyymmdd')||' 07:30:00'
                                               ) t2 
                                               where 1=1
                                               and t1.pernr=t2.pernr(+)
                                               and t1.datum=to_date(to_char(sysdate,'yyyymmdd'),'yyyymmdd')
                                                ) aa
                                                group by aa.pernr, aa.datum, aa.tprog,aa.CTPROG,aa.WORKHOUR,aa.worktime
                                            ) aa,
                                            (
                                              select t.pernr,t.nightrecord
                                              from wh_mis_cardata t 
                                              where t.clockdate=to_date(to_char(sysdate,'yyyymmdd'),'yyyymmdd')
                                              and t.retro='一般'
                                            ) bb,
                                            wh_users cc,wh_group dd
                                            where 
                                            aa.pernr=cc.ext
                                            and aa.pernr=bb.pernr(+)
                                            and (aa.leavestart is null or aa.worktime<aa.leavestart or aa.leavehour<8)
                                            and (aa.leavestart>trunc(sysdate,'dd')+8/24 or aa.leaveend<trunc(sysdate,'dd')+8/24 or aa.leavestart is null) --請假時間包含打卡結算時間就不算
                                            and (aa.leavestart>trunc(sysdate,'dd')+20/24 or aa.leaveend<trunc(sysdate,'dd')+20/24 or aa.leavestart is null)
                                            and aa.worktime<sysdate
                                            and (bb.pernr is null or (instr(aa.TPROG,'N')>0 and bb.nightrecord='N'))
                                            and cc.dept=dd.groupdesc
                                             and dd.groupid in('20','30','40','50')
                                       ) ee
                                       where ee.tprog='{0}'
                                       group by ee.fab
                                      order by ee.fab  ";
            sql = string.Format(sql, DayNight);
            return sql;

        }
        public string SetMailInfo(string classname)
        {
            sqlStr = @"select decode(t.wh_mailtype,1,'TO','CC') mailtype,t.wh_reportmailuser 
                       from wh_rpt_reportmail t
                       where t.wh_report_name='{0}'
                         and t.wh_mailtype in(1,2)
                       order by t.wh_mailtype ";
            sqlStr = string.Format(sqlStr, classname);
            return sqlStr;
        }
    }
}
